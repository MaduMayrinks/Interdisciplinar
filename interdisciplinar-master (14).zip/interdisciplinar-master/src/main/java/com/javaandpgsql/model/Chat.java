
package com.javaandpgsql.model;


public class Chat {
    private int tag;
    private String nome;
    private String texto; 
    private String Comunidade; 

    public Chat(int tag, String nome, String texto, String Comunidade) {
        this.tag = tag;
        this.nome = nome;
        this.texto = texto;
        this.Comunidade = Comunidade;
        
    }

    public Chat() {
    }

    
    public int getTag() {
        return tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getComunidade() {
        return Comunidade;
    }

    public void setComunidade(String Comunidade) {
        this.Comunidade = Comunidade;
    }

    @Override
    public String toString() {
        return nome +":" + texto;
    }

    
    
    
}
