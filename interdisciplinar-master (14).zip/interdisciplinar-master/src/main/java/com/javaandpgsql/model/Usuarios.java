package com.javaandpgsql.model;

/**
 *
 * @author janio.silva
 */
public class Usuarios {

    private int idade;
    private String nome;
    private String email;
    private String senha;
    private String genero;
    private String nomeUsuario;
    private int codigoemail;
    private String imagem;
    private int tag;
    private int estado;

    public Usuarios(int idade, String nome, String email, String senha, String genero, String nomeUsuario, int codigoemail, String imagem, int tag,int estado) {
        this.idade = idade;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.genero = genero;
        this.nomeUsuario = nomeUsuario;
        this.codigoemail = codigoemail;
        this.imagem = imagem;
        this.tag = tag;
        this.estado=estado;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public Usuarios() {
    }

    public int getTag() {
        return tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigoEmail() {
        return codigoemail;
    }

    public void setCodigoEmail(int codigoemail) {
        this.codigoemail = codigoemail;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    @Override
    public String toString() {
        //return "Usuarios{" + "ra=" + ra + ", idade=" + idade + ", nome=" + nome + ", codigoEmail=" + codigoEmail + ", email=" + email + ", senha=" + senha + '}';
      return "#"+ tag + "_"+ nome;
    }

}
