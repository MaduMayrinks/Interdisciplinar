package com.javaandpgsql.model;

public class Comunidade {

    private String Imagem;
    private String descricao;
    private int recomenda_idade;
    private String nome;
    private String nomedono;
    private int tag;
    private String genero;
    private int tagUsuario;
    private int codigoGenero;

    public Comunidade(String Imagem, String descricao, int recomenda_idade, String nome, String nomedono, int tag, String genero, int tagUsuario) {
        this.Imagem = Imagem;
        this.descricao = descricao;
        this.recomenda_idade = recomenda_idade;
        this.nome = nome;
        this.nomedono = nomedono;
        this.tag = tag;
        this.genero = genero;
        this.tagUsuario = tagUsuario;
    }

    public Comunidade(String Imagem, String descricao, int recomenda_idade, String nome, String nomedono, int tag, int codigoGeneroParam, int tagUsuario) {
        

        this.Imagem = Imagem;
        this.descricao = descricao;
        this.recomenda_idade = recomenda_idade;
        this.nome = nome;
        this.nomedono = nomedono;
        this.tag = tag;
        this.codigoGenero = codigoGeneroParam;
        this.tagUsuario = tagUsuario;
    }

    public Comunidade() {
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getTagUsuario() {
        return tagUsuario;
    }

    public void setTagUsuario(int tagUsuario) {
        this.tagUsuario = tagUsuario;
    }

    public String getImagem() {
        return Imagem;
    }

    public void setImagem(String Imagem) {
        this.Imagem = Imagem;
    }

    public int getRecomenda_idade() {
        return recomenda_idade;
    }

    public void setRecomenda_idade(int recomenda_idade) {
        this.recomenda_idade = recomenda_idade;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTag() {
        return tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }

    public String getNomedono() {
        return nomedono;
    }

    public void setNomedono(String nomedono) {
        this.nomedono = nomedono;
    }

    public int getCodigoGenero() {
        return codigoGenero;
    }

    public void setCodigoGenero(int codigoGenero) {
        this.codigoGenero = codigoGenero;
    }

    @Override
    public String toString() {
        return "" + "" + nome + "";
    }

}
