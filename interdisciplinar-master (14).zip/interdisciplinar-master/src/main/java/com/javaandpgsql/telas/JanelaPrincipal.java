package com.javaandpgsql.telas;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class JanelaPrincipal extends javax.swing.JFrame {

    public JanelaPrincipal() {
        initComponents();
        setTitle("CYP");
        baixando();
        this.setLocationRelativeTo(null);
        try {
            this.jPanel2 = new JanelaPrincipal.FonteLabel(this.criadores);
            this.jPanel2 = new JanelaPrincipal.FonteLabel(this.sobreoCYP);

        } catch (Exception ex) {
            Logger.getLogger(JanelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public class FonteLabel extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteLabel(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 11);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public class FonteBoton extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteBoton(JButton anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 17);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        logar = new javax.swing.JLabel();
        cadastrar = new javax.swing.JLabel();
        criadores = new javax.swing.JLabel();
        sobreoCYP = new javax.swing.JLabel();
        fotofundi = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                logarMousePressed(evt);
            }
        });
        jPanel2.add(logar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 390, -1, 140));

        cadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cadastrarMousePressed(evt);
            }
        });
        jPanel2.add(cadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 280, 570, 120));

        criadores.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        criadores.setForeground(new java.awt.Color(243, 238, 238));
        criadores.setText("Criadores");
        criadores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                criadoresMousePressed(evt);
            }
        });
        jPanel2.add(criadores, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 110, 20));

        sobreoCYP.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        sobreoCYP.setForeground(new java.awt.Color(243, 238, 238));
        sobreoCYP.setText("Sobre o CYP      |");
        sobreoCYP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                sobreoCYPMousePressed(evt);
            }
        });
        jPanel2.add(sobreoCYP, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 120, 20));
        jPanel2.add(fotofundi, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1490, 730));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void criadoresMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_criadoresMousePressed
        // TODO add your handling code here:
        SobreNos redirecionar = new SobreNos();
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_criadoresMousePressed

    private void sobreoCYPMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sobreoCYPMousePressed
        sobreCYP redirecionar = new sobreCYP();
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_sobreoCYPMousePressed

    private void cadastrarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarMousePressed
        // TODO add your handling code here:
        CadastroUsuario redirecionar = new CadastroUsuario();

        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_cadastrarMousePressed

    private void logarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logarMousePressed
        // TODO add your handling code here:
        LoginUsuario redirecionar = new LoginUsuario();

        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_logarMousePressed
    private void baixando() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\janelaprincipal.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1490, 720, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundi.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(JanelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\cadastrarbtn.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(719, 347, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                cadastrar.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(JanelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\loginbtn.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(719, 347, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                logar.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JanelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel cadastrar;
    private javax.swing.JLabel criadores;
    private javax.swing.JLabel fotofundi;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel logar;
    private javax.swing.JLabel sobreoCYP;
    // End of variables declaration//GEN-END:variables
}
