package com.javaandpgsql.telas;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class SobreNos extends javax.swing.JFrame {

    public SobreNos() {
        initComponents();
        this.setLocationRelativeTo(null);
        baixando();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        maislbl = new javax.swing.JLabel();
        voltarlbl = new javax.swing.JLabel();
        sobre = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(51, 27, 108));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        maislbl.setBackground(new java.awt.Color(234, 231, 231));
        maislbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        maislbl.setForeground(new java.awt.Color(234, 231, 231));
        maislbl.setText("+");
        maislbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                maislblMousePressed(evt);
            }
        });
        jPanel1.add(maislbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 760, 34, -1));

        voltarlbl.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        voltarlbl.setForeground(new java.awt.Color(245, 241, 241));
        voltarlbl.setText("Voltar");
        voltarlbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                voltarlblMousePressed(evt);
            }
        });
        jPanel1.add(voltarlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1530, 10, -1, 30));

        sobre.setIcon(new javax.swing.ImageIcon("C:\\Users\\0068957\\Downloads\\interdisciplinar-master\\interdisciplinar-master\\src\\main\\java\\com\\javaandpgsql\\imagem\\telasobrenos.png")); // NOI18N
        jPanel1.add(sobre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 1490, 710));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1595, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void voltarlblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_voltarlblMousePressed
        // TODO add your handling code here:
        JanelaPrincipal redirecionar = new JanelaPrincipal();
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_voltarlblMousePressed

    private void maislblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_maislblMousePressed
        // TODO add your handling code here:
        SobreNos2 redirecionar = new SobreNos2();
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_maislblMousePressed

    private void baixando() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\telasobrenos.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1490, 720, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                sobre.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(SobreNos.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SobreNos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SobreNos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SobreNos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SobreNos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SobreNos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel maislbl;
    private javax.swing.JLabel sobre;
    private javax.swing.JLabel voltarlbl;
    // End of variables declaration//GEN-END:variables
}
