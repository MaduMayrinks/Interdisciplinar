package com.javaandpgsql.telas;

import Controll.ControllerComunidade;
import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ComunidadesUsuario extends javax.swing.JFrame {

    private DefaultListModel<List> listacomunidades = new DefaultListModel<>();
    private DefaultListModel<List> listatag = new DefaultListModel<>();
    private Usuarios DadosUsuario;
    private List comunidadeselecionada;
    private ControllerComunidade servicocomunidade = new ControllerComunidade();
    private ControllerUsuarios controlando = new ControllerUsuarios();
    public boolean FECHANDO_PELO_MENU = true;
    private int voltar = 0;

    private JFrame frame;


    public ComunidadesUsuario(Usuarios dados) {
        initComponents();
        setTitle("CYP");
        setLocationRelativeTo(null);
        baixaImagemfundoLUA();
        DadosUsuario = dados;
        UsuariosLista(dados);
        frame = this;
        VerificaFechamento();
    }

    public ComunidadesUsuario(Comunidade ComunidadeCadastrada) {
        initComponents();
        setTitle("CYP");
         frame = this;
        VerificaFechamento();
    }

    private ComunidadesUsuario() {

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        labelVoltar = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListaNomesComunidades = new javax.swing.JList<>();
        labelfotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelVoltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                labelVoltarMousePressed(evt);
            }
        });
        jPanel1.add(labelVoltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(-90, 360, -1, -1));

        ListaNomesComunidades.setBackground(new java.awt.Color(255, 255, 204));
        ListaNomesComunidades.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ListaNomesComunidadesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(ListaNomesComunidades);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 630, 310));
        jPanel1.add(labelfotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 570));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ListaNomesComunidadesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ListaNomesComunidadesMouseClicked
        if (evt.getClickCount() >= 2) {
            Object selecionado = ListaNomesComunidades.getModel().getElementAt(ListaNomesComunidades.getSelectedIndex());
            Comunidade selecionada = (Comunidade) selecionado;
            MinhaComunidade telaAlteracaoComunidade = new MinhaComunidade(selecionada, DadosUsuario);
            telaAlteracaoComunidade.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            telaAlteracaoComunidade.setVisible(true);
        }
    }//GEN-LAST:event_ListaNomesComunidadesMouseClicked

    private void labelVoltarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelVoltarMousePressed
        // TODO add your handling code here:
        TelaPrincipal redirecionar = new TelaPrincipal(DadosUsuario);
        voltar++;
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_labelVoltarMousePressed
    private void UsuariosLista(Usuarios dados) {

        List<Comunidade> lista = servicocomunidade.PegarComunidadeUsuario(dados);
        DefaultListModel dlm = new DefaultListModel();
        dlm.addAll(lista);
        ListaNomesComunidades.setModel(dlm);
    }

    private void baixaImagemfundoLUA() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\ComunidadesUsuario.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1024, 576, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                labelfotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(ComunidadesUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\voltar (1).png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(300, 169, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                labelVoltar.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);

        }

    }
    private void VerificaFechamento() {
        //Aqui ele verifica se o usuario clicou para sair do programa
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                 if(voltar<0){ 
                   if (FECHANDO_PELO_MENU) {
                    int resposta
                            = JOptionPane.showConfirmDialog(null, "Você irá sair do programa, você tem certeza?", "Você tem certeza", JOptionPane.YES_NO_OPTION);
                    //Se o usuario quer fechar o programa
                    //ele o deixa offline
                    if (resposta == JOptionPane.YES_OPTION) {
                       
                        DadosUsuario.setEstado(0);
                        controlando.updateEstadoUsuario(DadosUsuario);

                        dispose();
                    } else {
                        //Se não ele continua executando normalmente
                        frame.setVisible(true);

                    }
                }}
                FECHANDO_PELO_MENU = true;
            }
        });
    }


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ComunidadesUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<List> ListaNomesComunidades;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelVoltar;
    private javax.swing.JLabel labelfotofundo;
    // End of variables declaration//GEN-END:variables
}
