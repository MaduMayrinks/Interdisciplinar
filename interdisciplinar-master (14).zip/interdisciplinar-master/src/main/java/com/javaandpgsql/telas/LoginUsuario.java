package com.javaandpgsql.telas;

import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Usuarios;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

public class LoginUsuario extends javax.swing.JFrame {

    private Usuarios dadosObtidos;

    public LoginUsuario() {
        initComponents();
        setTitle("CYP");
        baixarImg();
        this.setLocationRelativeTo(null);

        try {
            this.jPanel1 = new LoginUsuario.FonteLabel(this.esqueceusenha);
            this.jPanel1 = new LoginUsuario.FonteLabel(this.erroLabelEmail);
            this.jPanel1 = new LoginUsuario.FonteLabel(this.erroLogin);
            this.jPanel1 = new LoginUsuario.FonteLabel(this.cadastrar);
            this.jPanel1 = new LoginUsuario.FonteLabel(this.naopossui);
            this.jPanel1 = new LoginUsuario.FonteBotao(this.loginBtn);
        } catch (Exception ex) {
            Logger.getLogger(LoginUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        esqueceusenha.setVisible(true);
        erroLabelEmail.setVisible(false);
        erroLogin.setVisible(false);
    }

    public LoginUsuario(Usuarios dados) {
        initComponents();
        setTitle("CYP");
        baixarImg();
        this.setLocationRelativeTo(null);

        try {
            this.jPanel1 = new LoginUsuario.FonteLabel(this.esqueceusenha);
            this.jPanel1 = new LoginUsuario.FonteLabel(this.erroLabelEmail);
            this.jPanel1 = new LoginUsuario.FonteLabel(this.erroLogin);
            this.jPanel1 = new LoginUsuario.FonteLabel(this.cadastrar);
            this.jPanel1 = new LoginUsuario.FonteLabel(this.naopossui);
            this.jPanel1 = new LoginUsuario.FonteBotao(this.loginBtn);

        } catch (Exception ex) {
            Logger.getLogger(LoginUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        esqueceusenha.setVisible(true);
        erroLabelEmail.setVisible(false);
        erroLogin.setVisible(false);
        dados = dadosObtidos;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtSenha = new javax.swing.JPasswordField();
        txtNome = new javax.swing.JTextField();
        txtNomeUsuario = new javax.swing.JTextField();
        txtIdade = new javax.swing.JTextField();
        txtGenero = new javax.swing.JTextField();
        cadastrarBtn = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        emailTxt = new javax.swing.JTextField();
        senhaLoginTxt = new javax.swing.JPasswordField();
        loginBtn = new javax.swing.JButton();
        erroLabelEmail = new javax.swing.JLabel();
        esqueceusenha = new javax.swing.JLabel();
        naopossui = new javax.swing.JLabel();
        cadastrar = new javax.swing.JLabel();
        erroLogin = new javax.swing.JLabel();
        labelfundo = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(118, 2, 100));

        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel1.setFont(new java.awt.Font("ISOCPEUR", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 255));
        jLabel1.setText("Seja Bem-Vindo ao CYP");

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel2.setText("✩");

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel3.setText("✩");

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel4.setText("✩");

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel5.setText("✩");

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel6.setText("✩");

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel7.setText("✩");

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel8.setText("✩");

        jLabel9.setBackground(new java.awt.Color(102, 102, 102));
        jLabel9.setFont(new java.awt.Font("ISOCPEUR", 0, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 255));
        jLabel9.setText("Cadastro");
        jLabel9.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(153, 153, 153))); // NOI18N

        jLabel10.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 153, 255));
        jLabel10.setText("Insira seu email:");

        jLabel12.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 153, 255));
        jLabel12.setText("Nome de Usuario:");

        jLabel13.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 153, 255));
        jLabel13.setText("Nome: ");

        jLabel14.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 153, 255));
        jLabel14.setText("Senha:");

        jLabel15.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 255));

        jLabel17.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(153, 153, 255));
        jLabel17.setText("Idade:");

        jLabel18.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(153, 153, 255));
        jLabel18.setText("Genero:");

        cadastrarBtn.setBackground(new java.awt.Color(51, 51, 51));
        cadastrarBtn.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        cadastrarBtn.setForeground(new java.awt.Color(204, 204, 255));
        cadastrarBtn.setText("Cadastrar!");
        cadastrarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(483, 483, 483)
                                .addComponent(jLabel4)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cadastrarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(jLabel8)
                                .addGap(273, 273, 273))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel14)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(txtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel13)
                                                .addGap(30, 30, 30)
                                                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel12)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(txtNomeUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel17)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(txtIdade, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel10)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(114, 114, 114)
                                                        .addComponent(jLabel15)))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jLabel9)
                                                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGap(0, 1, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel18)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtGenero, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(15, 15, 15)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7)
                                .addGap(59, 59, 59)
                                .addComponent(cadastrarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(131, 131, 131))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(22, 22, 22)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(txtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel14)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtNomeUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel12))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtIdade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel18)
                                    .addComponent(txtGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(86, 86, 86)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 44, Short.MAX_VALUE))))))
        );

        jLabel16.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(204, 204, 255));
        jLabel16.setText("Email ou Nome de usuário:");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(78, 43, 182));
        jPanel2.setPreferredSize(new java.awt.Dimension(1040, 600));

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setPreferredSize(new java.awt.Dimension(880, 490));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(emailTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 180, 280, -1));

        senhaLoginTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                senhaLoginTxtKeyPressed(evt);
            }
        });
        jPanel3.add(senhaLoginTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 270, 280, -1));

        loginBtn.setBackground(new java.awt.Color(51, 51, 51));
        loginBtn.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        loginBtn.setForeground(new java.awt.Color(204, 204, 255));
        loginBtn.setText("Logar");
        loginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginBtnActionPerformed(evt);
            }
        });
        jPanel3.add(loginBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 390, 178, 38));

        erroLabelEmail.setForeground(new java.awt.Color(255, 0, 51));
        erroLabelEmail.setText("email incorreto");
        jPanel3.add(erroLabelEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 210, -1, -1));

        esqueceusenha.setForeground(new java.awt.Color(78, 43, 182));
        esqueceusenha.setText("Esqueceu sua senha?");
        esqueceusenha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                esqueceusenhaMousePressed(evt);
            }
        });
        jPanel3.add(esqueceusenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 300, -1, 20));

        naopossui.setText("Não possui conta?");
        jPanel3.add(naopossui, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 450, -1, -1));

        cadastrar.setForeground(new java.awt.Color(78, 43, 182));
        cadastrar.setText("Cadastre-se!");
        cadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cadastrarMousePressed(evt);
            }
        });
        jPanel3.add(cadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 450, 80, -1));

        erroLogin.setForeground(new java.awt.Color(255, 0, 0));
        erroLogin.setText("senha incorreta");
        jPanel3.add(erroLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 300, 170, 20));
        jPanel3.add(labelfundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 0, 880, 490));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(213, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 859, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(211, 211, 211))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(137, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1283, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 743, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
public class FonteLabel extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteLabel(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 11);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public class FonteBotao extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteBotao(JButton anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 19);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }
    private void cadastrarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarBtnActionPerformed

    }//GEN-LAST:event_cadastrarBtnActionPerformed

    public void baixarImg() {
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\logar.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(880, 495, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                labelfundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(LoginUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void loginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginBtnActionPerformed
        //verificando se o email existe...
        if (emailTxt.getText().isEmpty() || (new String(senhaLoginTxt.getPassword()).isEmpty())) {
            erroLabelEmail.setText("Insira todos os componentes.");
            erroLabelEmail.setVisible(true);
        } else {
            ControllerUsuarios controle = new ControllerUsuarios();

            //verificando email e senha...
            if (controle.verificaLogin(emailTxt.getText(), (new String(senhaLoginTxt.getPassword())))) {

                //retornando a tag
                int tagDoUsuarioLogado = controle.retornandoTag(emailTxt.getText(), (new String(senhaLoginTxt.getPassword())));

                String email = controle.retornandoEmail(tagDoUsuarioLogado);
                String nomeObtido = controle.retornandoNome(tagDoUsuarioLogado);
                String NomeUsuario = controle.retornandoNomeU(tagDoUsuarioLogado);
                int idadeUsuario = controle.retornandoIdade(tagDoUsuarioLogado);
                String genero = controle.retornandoGenero(tagDoUsuarioLogado);
                String senha = controle.retornandoSenha(tagDoUsuarioLogado);
                String imagem = controle.retornandoImagem(tagDoUsuarioLogado);
                int estado = 1;
                dadosObtidos = new Usuarios(idadeUsuario, nomeObtido, email, senha, genero, NomeUsuario, 0, imagem, tagDoUsuarioLogado, estado);
                TelaPrincipal principal = new TelaPrincipal(dadosObtidos);
                principal.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                principal.setVisible(true);
                dispose();
            } else {

                erroLogin.setText("Email ou senha incorretos.");
                erroLogin.setVisible(true);

            }
        }

    }//GEN-LAST:event_loginBtnActionPerformed

    private void cadastrarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarMousePressed
        // TODO add your handling code here:
        CadastroUsuario cad = new CadastroUsuario();
        cad.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cad.setVisible(true);
        dispose();
    }//GEN-LAST:event_cadastrarMousePressed

    private void esqueceusenhaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_esqueceusenhaMousePressed
        esquecisenha refazersenha = new esquecisenha(dadosObtidos);
        refazersenha.setVisible(true);
        dispose();
    }//GEN-LAST:event_esqueceusenhaMousePressed

    private void senhaLoginTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_senhaLoginTxtKeyPressed
        if (evt.getKeyCode() == 10) {

            if (emailTxt.getText().isEmpty() || (new String(senhaLoginTxt.getPassword()).isEmpty())) {
                erroLabelEmail.setText("Insira todos os componentes.");
                erroLabelEmail.setVisible(true);
            } else {
                ControllerUsuarios controle = new ControllerUsuarios();

                //verificando email e senha...
                if (controle.verificaLogin(emailTxt.getText(), (new String(senhaLoginTxt.getPassword())))) {

                    //retornando a tag
                    int tagDoUsuarioLogado = controle.retornandoTag(emailTxt.getText(), (new String(senhaLoginTxt.getPassword())));

                    String email = controle.retornandoEmail(tagDoUsuarioLogado);
                    String nomeObtido = controle.retornandoNome(tagDoUsuarioLogado);
                    String NomeUsuario = controle.retornandoNomeU(tagDoUsuarioLogado);
                    int idadeUsuario = controle.retornandoIdade(tagDoUsuarioLogado);
                    String genero = controle.retornandoGenero(tagDoUsuarioLogado);
                    String senha = controle.retornandoSenha(tagDoUsuarioLogado);
                    String imagem = controle.retornandoImagem(tagDoUsuarioLogado);
                    int estado = 1;
                    dadosObtidos = new Usuarios(idadeUsuario, nomeObtido, email, senha, genero, NomeUsuario, 0, imagem, tagDoUsuarioLogado, estado);
                    TelaPrincipal principal = new TelaPrincipal(dadosObtidos);
                    principal.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                    principal.setVisible(true);
                    dispose();
                } else {

                    erroLogin.setText("Email ou senha incorretos.");
                    erroLogin.setVisible(true);

                }
            }
        }


    }//GEN-LAST:event_senhaLoginTxtKeyPressed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel cadastrar;
    private javax.swing.JButton cadastrarBtn;
    private javax.swing.JTextField emailTxt;
    private javax.swing.JLabel erroLabelEmail;
    private javax.swing.JLabel erroLogin;
    private javax.swing.JLabel esqueceusenha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel labelfundo;
    private javax.swing.JButton loginBtn;
    private javax.swing.JLabel naopossui;
    private javax.swing.JPasswordField senhaLoginTxt;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtGenero;
    private javax.swing.JTextField txtIdade;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtNomeUsuario;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
