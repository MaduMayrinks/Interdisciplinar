package com.javaandpgsql.telas;

import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;

public class ModelComunidade extends javax.swing.JPanel {

    private Usuarios Meusdados;
    private String nomeC;
    private int idade;
    private String caminho = System.getProperty("user.home");
    private String iconPath = caminho + "\\src\\imagens\\4fcaf80db6845d97077fc69443c9df25.jpg";
    private ImageIcon originalIcon = new ImageIcon(iconPath);
    private ImageIcon resizedIcon = resizeIcon(originalIcon, 40, 40);

    public ModelComunidade(int repassaTag, Comunidade NovaComunidade, Usuarios Dados) {

        initComponents();

        Meusdados = Dados;
        idade = NovaComunidade.getRecomenda_idade();
        nomeC = NovaComunidade.getNome();
        labeltag.setText(String.valueOf(repassaTag));
        nomeComunity.setText(NovaComunidade.getNome());
        BaixarImagemComunidade(NovaComunidade.getImagem());

        try {
            this.jPanel1 = new ModelComunidade.FonteLabel(this.nomeComunity);
            this.jPanel1 = new ModelComunidade.FonteLabel(this.labeltag);
        } catch (Exception ex) {
            Logger.getLogger(ModelComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private static ImageIcon resizeIcon(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image resizedImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImg);
    }

    public class FonteLabel extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteLabel(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 12);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nomeComunity = new javax.swing.JLabel();
        labeltag = new javax.swing.JLabel();
        LabelFTComunidade = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();

        setBackground(new java.awt.Color(98, 62, 171));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nomeComunity.setText("nome");
        nomeComunity.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                nomeComunityMousePressed(evt);
            }
        });
        add(nomeComunity, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 110, 20));

        labeltag.setForeground(new java.awt.Color(255, 255, 255));
        labeltag.setText("#");
        add(labeltag, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 30, 20));

        LabelFTComunidade.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 0), 2));
        LabelFTComunidade.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                LabelFTComunidadeMousePressed(evt);
            }
        });
        add(LabelFTComunidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 190));

        jPanel1.setBackground(new java.awt.Color(98, 62, 171));
        jPanel1.setForeground(new java.awt.Color(98, 62, 171));
        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 230));
    }// </editor-fold>//GEN-END:initComponents

    private void LabelFTComunidadeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LabelFTComunidadeMousePressed
      if (Meusdados.getIdade() >= idade) {
            TelaDentroComunidade redirecionar = new TelaDentroComunidade(labeltag.getText(), Meusdados, nomeC);
            redirecionar.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Você não tem a idade recomendada para ingressar na comunidade", "Idade insuficiente", JOptionPane.INFORMATION_MESSAGE, resizedIcon);

        }
    }//GEN-LAST:event_LabelFTComunidadeMousePressed

    private void BaixarImagemComunidade(String imagem) {
        SwingWorker AtualizaOnline = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                URL novaURl;
                File arq;

                try {

                    if (imagem.startsWith("https") || imagem.startsWith("http")) {
                        novaURl = new URL(imagem);
                        BufferedImage imagemcomunidade = ImageIO.read(novaURl);
                        ImageIcon imgI = new ImageIcon(imagemcomunidade);
                        imgI.setImage(imgI.getImage().getScaledInstance(160, 190, 100));
                        LabelFTComunidade.setIcon(imgI);
                    } else {
                        arq = new File(imagem);
                        if (arq.exists()) {
                            BufferedImage imagemmmm = ImageIO.read(arq);
                            ImageIcon imgI = new ImageIcon(imagemmmm);
                            imgI.setImage(imgI.getImage().getScaledInstance(160, 190, 100));
                            LabelFTComunidade.setIcon(imgI);
                        } else {
                            System.err.println("O arquivo não existe: " + imagem);
                        }
                    }
                } catch (MalformedURLException ex) {
                    ex.printStackTrace();

                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                return null;
            }
        };
        AtualizaOnline.execute();
    }

    private void nomeComunityMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nomeComunityMousePressed
        if (Meusdados.getIdade() >= idade) {
            TelaDentroComunidade redirecionar = new TelaDentroComunidade(labeltag.getText(), Meusdados, nomeC);
            redirecionar.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Você não tem a idade recomendada para ingressar na comunidade", "Idade insuficiente", JOptionPane.INFORMATION_MESSAGE, resizedIcon);

        }
    }//GEN-LAST:event_nomeComunityMousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelFTComunidade;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labeltag;
    private javax.swing.JLabel nomeComunity;
    // End of variables declaration//GEN-END:variables
}
