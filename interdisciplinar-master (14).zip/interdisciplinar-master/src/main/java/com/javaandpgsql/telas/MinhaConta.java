package com.javaandpgsql.telas;

import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Usuarios;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class MinhaConta extends javax.swing.JFrame {

    private String urlImagem;
    private Usuarios remandados;
    private String nome = " ";
    private String nomeUsuario = " ";
    private String email = " ";
    private String senha = " ";
    private String imagem = " ";
    private Random gerador = new Random();

    private int contEmail = 0;
    private int contSenha = 0;
    private ControllerUsuarios controlando = new ControllerUsuarios();
    private int contsenhaverifica = 0;
    private int contemailverifica = 0;
    private int contverificacao = 0;
    public boolean FECHANDO_PELO_MENU = true;
    private JFrame frame;

    public MinhaConta() {
        initComponents();
        setTitle("CYP");
        this.setLocationRelativeTo(null);
        frame = this;
        baixaImagemfundoLUA();
        
        try {
            nometxt.setVisible(false);
            nicknameTxt.setVisible(false);
            emailtxt.setVisible(false);
            senhatxt.setVisible(false);

            salvaNomeU.setVisible(false);
            salvaEmail.setVisible(false);
            salvaNick.setVisible(false);
            salvaSenha.setVisible(false);

            this.jPanel1 = new MinhaConta.TesteFonte(this.labelNome);
            this.jPanel1 = new MinhaConta.TesteFonte(this.labelNickname);
            this.jPanel1 = new MinhaConta.TesteFonte(this.labelemail);
            this.jPanel1 = new MinhaConta.TesteFonte(this.labelsenha);
            this.jPanel1 = new MinhaConta.TesteFonte(this.tagUsuario);

        } catch (Exception ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public MinhaConta(Usuarios dados) {

        initComponents();
        frame = this;
        baixaImagemfundoLUA();
        //Igualando dadosrecebidos com remandados, para reenviar os dados atualizados, ou os mesmo para atualizar
        remandados = dados;
        //Mudando título
        setTitle("CYP");
        int tag = remandados.getTag();
        tagUsuario.setText("#" + String.valueOf(tag));
        //tentando mudar os labels para visivel e não visivel
        try {

            nometxt.setVisible(false);
            nicknameTxt.setVisible(false);
            emailtxt.setVisible(false);
            senhatxt.setVisible(false);

            //Dados do usuário:
            labelNome.setText(dados.getNome());
            labelNickname.setText(dados.getNomeUsuario());
            labelemail.setText(dados.getEmail());
            labelsenha.setText(dados.getSenha());

            //Outros labels...
            salvaNomeU.setVisible(false);
            salvaEmail.setVisible(false);
            salvaNick.setVisible(false);
            salvaSenha.setVisible(false);

            this.jPanel1 = new MinhaConta.TesteFonte(this.labelNome);
            this.jPanel1 = new MinhaConta.TesteFonte(this.labelNickname);
            this.jPanel1 = new MinhaConta.TesteFonte(this.labelemail);
            this.jPanel1 = new MinhaConta.TesteFonte(this.labelsenha);

        } catch (Exception ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }

        //centralizando
        this.setLocationRelativeTo(null);

        //baixando imagem de usuario
        baixaImagem(dados);

    }

    private static ImageIcon resizeIcon(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image resizedImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImg);
    }

    public void verificacaoconta() {

        String caminho = System.getProperty("user.home");
        String iconPath = caminho + "\\src\\imagens\\4fcaf80db6845d97077fc69443c9df25.jpg";
        ImageIcon originalIcon = new ImageIcon(iconPath);
        ImageIcon resizedIcon = resizeIcon(originalIcon, 40, 40);

        int geranumeroverfica = gerador.nextInt(1000, 9000);
        int codigo = geranumeroverfica;
        int codigo2 = geranumeroverfica;

        File arquivoverificacaosenha = new File(caminho + "\\Desktop\\verificacaoconta.txt");
        if (editarEmail.isEnabled()) {
            JOptionPane.showMessageDialog(null, "ESTA HABILITADO");
        }
        try {
            arquivoverificacaosenha.createNewFile();
            FileWriter escrita = new FileWriter(arquivoverificacaosenha, false);
            BufferedWriter bufEscrita = new BufferedWriter(escrita);
            String TranformaGerador = String.valueOf(codigo);
            String TranformaGerador2 = String.valueOf(codigo2);

            if (contemailverifica == 1) {
                bufEscrita.write("Insira seu código de Verificação de email : " + "\n");
                bufEscrita.write(TranformaGerador + "\n");
                bufEscrita.flush();
                bufEscrita.close();
            }
            if (contsenhaverifica == 2) {
                bufEscrita.write("Insira seu código de Verificação de senha : " + "\n");
                bufEscrita.write(TranformaGerador + "\n");
                bufEscrita.flush();
                bufEscrita.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        UIManager.put("OptionPane.background", new Color(78, 43, 182));
        UIManager.put("Panel.background", new Color(78, 43, 182));
        UIManager.put("OptionPane.messageForeground", Color.WHITE);

        String userInput = (String) JOptionPane.showInputDialog(
                null,
                "O código de verificação está na sua área de trabalho:",
                "Verificação de senha",
                JOptionPane.INFORMATION_MESSAGE,
                resizedIcon,
                null,
                "");
        // Exibir a entrada do usuário (ou cancelamento)
        if (userInput != null && !userInput.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Você digitou: " + userInput,
                    "Mensagem",
                    JOptionPane.INFORMATION_MESSAGE,
                    resizedIcon
            );
        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "Operação cancelada",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE,
                    resizedIcon
            );

        }
        int transformanumero = Integer.parseInt(userInput);

        while (transformanumero != geranumeroverfica) {
            JOptionPane.showMessageDialog(null, "Insira o número de verificação correto", "Erro de Verificação", JOptionPane.ERROR_MESSAGE);
            userInput = JOptionPane.showInputDialog(null, "Insira o código de Verificação", "Verificação de esenha", JOptionPane.INFORMATION_MESSAGE);
            transformanumero = Integer.parseInt(userInput);
        }
        if (transformanumero == geranumeroverfica) {
            JOptionPane.showMessageDialog(null, "Verificação correta!", "Sucesso!", JOptionPane.INFORMATION_MESSAGE);
            contverificacao = 0;
            arquivoverificacaosenha.delete();

        }

    }

    //Fonte do JFrame
    public class TesteFonte extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public TesteFonte(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 16);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    private void baixaImagem(Usuarios dados) {

        URL novaURl;

        try {
            novaURl = new URL(dados.getImagem());

            BufferedImage imagemmmm = ImageIO.read(novaURl);
            ImageIcon imgI = new ImageIcon(imagemmmm);
            imgI.setImage(imgI.getImage().getScaledInstance(150, 150, 100));
            ImagemLbl.setIcon(imgI);

        } catch (MalformedURLException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void baixaImagemfundoLUA() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\minhaconta.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1490, 720, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                labelMinhaConta.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\SALVAR.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(310, 310, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                salvarDados.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\voltar.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(310, 310, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                voltarLbl.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        nometxt = new javax.swing.JTextField();
        nicknameTxt = new javax.swing.JTextField();
        emailtxt = new javax.swing.JTextField();
        senhatxt = new javax.swing.JTextField();
        linhadebaixo = new javax.swing.JLabel();
        linhadebaixo2 = new javax.swing.JLabel();
        linhadebaixo3 = new javax.swing.JLabel();
        linhadebaixo4 = new javax.swing.JLabel();
        editarNomeU = new javax.swing.JLabel();
        editarNick = new javax.swing.JLabel();
        editarEmail = new javax.swing.JLabel();
        editarSenha = new javax.swing.JLabel();
        EditarImagem = new javax.swing.JLabel();
        linhadebaixo5 = new javax.swing.JLabel();
        salvaNomeU = new javax.swing.JLabel();
        salvaNick = new javax.swing.JLabel();
        salvaEmail = new javax.swing.JLabel();
        salvaSenha = new javax.swing.JLabel();
        ImagemLbl = new javax.swing.JLabel();
        labelsenha = new javax.swing.JLabel();
        labelNickname = new javax.swing.JLabel();
        salvarDados = new javax.swing.JLabel();
        labelemail = new javax.swing.JLabel();
        labelNome = new javax.swing.JLabel();
        voltarLbl = new javax.swing.JLabel();
        tagUsuario = new javax.swing.JLabel();
        labelMinhaConta = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(nometxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 210, 190, -1));
        jPanel1.add(nicknameTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 280, 290, -1));
        jPanel1.add(emailtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 360, 350, -1));
        jPanel1.add(senhatxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 440, 350, -1));

        linhadebaixo.setForeground(new java.awt.Color(255, 204, 0));
        linhadebaixo.setText("________________________");
        jPanel1.add(linhadebaixo, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 200, 260, 40));

        linhadebaixo2.setForeground(new java.awt.Color(255, 204, 0));
        linhadebaixo2.setText("________________________________");
        jPanel1.add(linhadebaixo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 280, 230, 30));

        linhadebaixo3.setForeground(new java.awt.Color(255, 204, 0));
        linhadebaixo3.setText("_____________________________________");
        jPanel1.add(linhadebaixo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 360, 280, 30));

        linhadebaixo4.setForeground(new java.awt.Color(255, 204, 0));
        linhadebaixo4.setText("_____________________________________");
        jPanel1.add(linhadebaixo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 440, 280, 30));

        editarNomeU.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        editarNomeU.setText("✎");
        editarNomeU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarNomeUMousePressed(evt);
            }
        });
        jPanel1.add(editarNomeU, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 190, 40, 40));

        editarNick.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        editarNick.setText("✎");
        editarNick.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarNickMousePressed(evt);
            }
        });
        jPanel1.add(editarNick, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 260, 40, 40));

        editarEmail.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        editarEmail.setText("✎");
        editarEmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarEmailMousePressed(evt);
            }
        });
        jPanel1.add(editarEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 340, 30, 40));

        editarSenha.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        editarSenha.setText("✎");
        editarSenha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarSenhaMousePressed(evt);
            }
        });
        jPanel1.add(editarSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 420, 40, 40));

        EditarImagem.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        EditarImagem.setText("  Editar");
        EditarImagem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                EditarImagemMousePressed(evt);
            }
        });
        jPanel1.add(EditarImagem, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 360, 50, 40));

        linhadebaixo5.setForeground(new java.awt.Color(255, 204, 0));
        linhadebaixo5.setText("___________");
        jPanel1.add(linhadebaixo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 380, -1, -1));

        salvaNomeU.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        salvaNomeU.setText("✔️");
        salvaNomeU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                salvaNomeUMousePressed(evt);
            }
        });
        jPanel1.add(salvaNomeU, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 190, 40, 40));

        salvaNick.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        salvaNick.setText("✔️");
        salvaNick.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                salvaNickMousePressed(evt);
            }
        });
        jPanel1.add(salvaNick, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 270, 40, 40));

        salvaEmail.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        salvaEmail.setText("✔️");
        salvaEmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                salvaEmailMousePressed(evt);
            }
        });
        jPanel1.add(salvaEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 350, 40, 40));

        salvaSenha.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        salvaSenha.setText("✔️");
        salvaSenha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                salvaSenhaMousePressed(evt);
            }
        });
        jPanel1.add(salvaSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 430, 40, 40));

        ImagemLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ImagemLbl.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 0), 2, true));
        jPanel1.add(ImagemLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 170, 180, 190));

        labelsenha.setForeground(new java.awt.Color(51, 64, 103));
        labelsenha.setText("**********");
        jPanel1.add(labelsenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 440, 230, 30));

        labelNickname.setForeground(new java.awt.Color(51, 64, 103));
        labelNickname.setText("exemplo");
        jPanel1.add(labelNickname, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 250, 290, 80));

        salvarDados.setText("Salvar");
        salvarDados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                salvarDadosMousePressed(evt);
            }
        });
        jPanel1.add(salvarDados, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 480, 230, 80));

        labelemail.setForeground(new java.awt.Color(51, 64, 103));
        labelemail.setText("exemplo@ex.com");
        jPanel1.add(labelemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 350, 420, 40));

        labelNome.setForeground(new java.awt.Color(51, 64, 103));
        labelNome.setText("exemplo");
        jPanel1.add(labelNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 200, 140, 30));

        voltarLbl.setText("Voltar");
        voltarLbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                voltarLblMousePressed(evt);
            }
        });
        jPanel1.add(voltarLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 500, 210, 60));

        tagUsuario.setText("#");
        jPanel1.add(tagUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 180, 40, -1));
        jPanel1.add(labelMinhaConta, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1470, 730));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1470, 730));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void editarNomeUMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarNomeUMousePressed
        // TODO add your handling code here:
        labelNome.setVisible(false);
        nometxt.setVisible(true);
        linhadebaixo.setVisible(false);
        editarNomeU.setVisible(false);
        salvaNomeU.setVisible(true);
    }//GEN-LAST:event_editarNomeUMousePressed

    private void editarNickMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarNickMousePressed
        // TODO add your handling code here:
        labelNickname.setVisible(false);
        nicknameTxt.setVisible(true);
        linhadebaixo2.setVisible(false);
        editarNick.setVisible(false);
        salvaNick.setVisible(true);
    }//GEN-LAST:event_editarNickMousePressed

    private void editarEmailMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarEmailMousePressed
        // TODO add your handling code here:
        labelemail.setVisible(false);
        emailtxt.setVisible(true);
        //VerificacaoEmail();
        linhadebaixo3.setVisible(false);
        editarEmail.setVisible(false);
        salvaEmail.setVisible(true);
    }//GEN-LAST:event_editarEmailMousePressed

    private void editarSenhaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarSenhaMousePressed
        // TODO add your handling code here:
        labelsenha.setVisible(false);
        senhatxt.setVisible(true);
        //VerificacaoSenha();
        linhadebaixo4.setVisible(false);
        editarSenha.setVisible(false);
        salvaSenha.setVisible(true);
    }//GEN-LAST:event_editarSenhaMousePressed

    private void EditarImagemMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EditarImagemMousePressed
        // TODO add your handling code here:
        MinhaImagem InsereImagem = new MinhaImagem(remandados);
        InsereImagem.setVisible(true);
       dispose();
    }//GEN-LAST:event_EditarImagemMousePressed

    private void salvaNomeUMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvaNomeUMousePressed

        if (nometxt.getText().isBlank()) {
            labelNome.setVisible(true);
            nometxt.setVisible(false);
            linhadebaixo.setVisible(true);
            salvaNomeU.setVisible(false);
            editarNomeU.setVisible(true);
        } else {
            //guardar no BD
            labelNome.setText(nometxt.getText());
            labelNome.setVisible(true);
            nometxt.setVisible(false);
            linhadebaixo.setVisible(true);
            salvaNomeU.setVisible(false);
            editarNomeU.setVisible(true);
            nome = nometxt.getText();
        }
    }//GEN-LAST:event_salvaNomeUMousePressed

    private void salvaNickMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvaNickMousePressed
        // TODO add your handling code here:
        if (nicknameTxt.getText().isBlank()) {
            labelNickname.setVisible(true);
            nicknameTxt.setVisible(false);
            linhadebaixo2.setVisible(true);
            salvaNick.setVisible(false);
            editarNick.setVisible(true);
        } else {
            labelNickname.setText(nicknameTxt.getText());
            labelNickname.setVisible(true);
            nicknameTxt.setVisible(false);
            linhadebaixo2.setVisible(true);
            salvaNick.setVisible(false);
            editarNick.setVisible(true);
            nomeUsuario = nicknameTxt.getText();
        }
    }//GEN-LAST:event_salvaNickMousePressed

    private void salvaEmailMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvaEmailMousePressed
        // TODO add your handling code here:
        if (emailtxt.getText().isBlank()) {
            labelemail.setVisible(true);
            emailtxt.setVisible(false);
            linhadebaixo3.setVisible(true);
            salvaEmail.setVisible(false);
            editarEmail.setVisible(true);
        } else {
            //guardar no BD

            //verificar se a senha antiga é a mesma que ele digitou atualmente...
            if (labelemail.getText() == emailtxt.getText()) {
                //não aparece pra verificar
                labelemail.setText(emailtxt.getText());
                labelemail.setVisible(true);
                emailtxt.setVisible(false);
                linhadebaixo3.setVisible(true);
                salvaEmail.setVisible(false);
                editarEmail.setVisible(true);
                email = emailtxt.getText();
            } else {
                //aparece pra verificar

                labelemail.setText(emailtxt.getText());
                labelemail.setVisible(true);
                emailtxt.setVisible(false);
                linhadebaixo3.setVisible(true);
                salvaEmail.setVisible(false);
                editarEmail.setVisible(true);
                email = emailtxt.getText();
            }
        }
    }//GEN-LAST:event_salvaEmailMousePressed

    private void salvaSenhaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvaSenhaMousePressed
        // TODO add your handling code here:
        if (senhatxt.getText().isBlank()) {
            labelsenha.setVisible(true);
            senhatxt.setVisible(false);
            linhadebaixo4.setVisible(true);
            salvaSenha.setVisible(false);
            editarSenha.setVisible(true);
        } else {
            //guardar no BD

            //verificar se a senha antiga é a mesma que ele digitou atualmente...
            
            labelsenha.setText(senhatxt.getText());
            labelsenha.setVisible(true);
            senhatxt.setVisible(false);
            linhadebaixo4.setVisible(true);
            salvaSenha.setVisible(false);
            editarSenha.setVisible(true);
            senha = senhatxt.getText();
  
            
            
        }
    }//GEN-LAST:event_salvaSenhaMousePressed

    private void salvarDadosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvarDadosMousePressed
        
            salvandoDados();
        
    }//GEN-LAST:event_salvarDadosMousePressed

    private void voltarLblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_voltarLblMousePressed
        //Redirecionando para o principal rainha os dados do usuario novamente
        TelaPrincipal redirecionar = new TelaPrincipal(remandados);
        redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_voltarLblMousePressed

     

    public void salvandoDados() {
        if (!email.isBlank()) {
            remandados.setEmail(email);
        }
        if (!imagem.isBlank()) {
            remandados.setImagem(imagem);
        }
        if (!nome.isBlank()) {
            remandados.setNome(nome);
        }
        if (!nomeUsuario.isBlank()) {
            remandados.setNomeUsuario(nomeUsuario);
        }
        if (!senha.isBlank()) {
            remandados.setSenha(senha);
        }
        controlando = new ControllerUsuarios();
        controlando.atualizandoConta(remandados);

    }
   
    


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MinhaConta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MinhaConta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MinhaConta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MinhaConta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Usuarios dados = null;

                new MinhaConta(dados).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel EditarImagem;
    private javax.swing.JLabel ImagemLbl;
    private javax.swing.JLabel editarEmail;
    private javax.swing.JLabel editarNick;
    private javax.swing.JLabel editarNomeU;
    private javax.swing.JLabel editarSenha;
    private javax.swing.JTextField emailtxt;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelMinhaConta;
    private javax.swing.JLabel labelNickname;
    private javax.swing.JLabel labelNome;
    private javax.swing.JLabel labelemail;
    private javax.swing.JLabel labelsenha;
    private javax.swing.JLabel linhadebaixo;
    private javax.swing.JLabel linhadebaixo2;
    private javax.swing.JLabel linhadebaixo3;
    private javax.swing.JLabel linhadebaixo4;
    private javax.swing.JLabel linhadebaixo5;
    private javax.swing.JTextField nicknameTxt;
    private javax.swing.JTextField nometxt;
    private javax.swing.JLabel salvaEmail;
    private javax.swing.JLabel salvaNick;
    private javax.swing.JLabel salvaNomeU;
    private javax.swing.JLabel salvaSenha;
    private javax.swing.JLabel salvarDados;
    private javax.swing.JTextField senhatxt;
    private javax.swing.JLabel tagUsuario;
    private javax.swing.JLabel voltarLbl;
    // End of variables declaration//GEN-END:variables

    public String getUrlImagem() {
        return urlImagem;
    }

    public void setUrlImagem(String urlImagem) {
        this.urlImagem = urlImagem;
    }

}
