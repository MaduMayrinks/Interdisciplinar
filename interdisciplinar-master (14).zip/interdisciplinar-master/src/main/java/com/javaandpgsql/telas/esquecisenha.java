
package com.javaandpgsql.telas;

import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Usuarios;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.UIManager;


public class esquecisenha extends javax.swing.JFrame {

    private Random gerador = new Random();
    private ControllerUsuarios controla = new ControllerUsuarios();
    private Usuarios dados = new Usuarios();
    private int transformanumero;
    private int geranumeroverfica;
    private File arquivoverificacaosenha;

    public esquecisenha(Usuarios DadosObtidos) {
        initComponents();
        baixando();
        labelerro.setVisible(false);
        setLocationRelativeTo(null);
        dados = DadosObtidos;
        txtnovasenha.setEnabled(false);
        confirmarsenha.setEnabled(false);
        txtcodigoo.setEnabled(false);
        verificacaosenha();
        labelerroemail.setVisible(false);
        Labelerrosenha.setVisible(false);
    }

    public esquecisenha() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private static ImageIcon resizeIcon(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image resizedImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImg);
    }

    public void verificacaosenha() {

        String caminho = System.getProperty("user.home");
        String iconPath = caminho + "\\src\\imagens\\4fcaf80db6845d97077fc69443c9df25.jpg";
        ImageIcon originalIcon = new ImageIcon(iconPath);
        ImageIcon resizedIcon = resizeIcon(originalIcon, 40, 40);

        if (!txtemail.getText().isEmpty()) {
            if (controla.verificaEmail(txtemail.getText()) == true) {
                txtcodigoo.setEnabled(true);
                txtemail.setEnabled(false);
                geranumeroverfica = gerador.nextInt(1000, 9000);
                int codigo = geranumeroverfica;

                arquivoverificacaosenha = new File(caminho + "\\Desktop\\verificacaosenha.txt");
                try {
                    arquivoverificacaosenha.createNewFile();
                    FileWriter escrita = new FileWriter(arquivoverificacaosenha, false);
                    BufferedWriter bufEscrita = new BufferedWriter(escrita);
                    String TranformaGerador = String.valueOf(geranumeroverfica);
                    bufEscrita.write("Insira seu código de Verificação: " + "\n");
                    bufEscrita.write(TranformaGerador + "\n");

                    bufEscrita.flush();
                    bufEscrita.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                UIManager.put("OptionPane.background", new Color(78, 43, 182));
                UIManager.put("Panel.background", new Color(78, 43, 182));
                UIManager.put("OptionPane.messageForeground", Color.WHITE);

                // Exibir a entrada do usuário (ou cancelamento)
                JOptionPane.showMessageDialog(
                        null,
                        "O código de verificação está na sua área de trabalho: ",
                        "Verificação de email",
                        JOptionPane.INFORMATION_MESSAGE,
                        resizedIcon
                );
                String codigonumero = txtcodigoo.getText();
                if (!(codigonumero.equalsIgnoreCase(""))) {
                    transformanumero = Integer.parseInt(codigonumero);
                }

            } else {

                labelerroemail.setVisible(true);
            }

        }
    }

    public void verificasenha2() {
        if (transformanumero != geranumeroverfica) {
            labelerro.setVisible(true);
        }
        String codigonumero = txtcodigoo.getText();
        if (!(codigonumero.equalsIgnoreCase(""))) {
            transformanumero = Integer.parseInt(codigonumero);
            if (transformanumero == geranumeroverfica) {
                txtcodigoo.setEnabled(false);
                arquivoverificacaosenha.delete();
                labelerro.setVisible(false);
                txtnovasenha.setEnabled(true);
                confirmarsenha.setEnabled(true);

            }

        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Labelerrosenha = new javax.swing.JLabel();
        labelerro = new javax.swing.JLabel();
        labelerroemail = new javax.swing.JLabel();
        volrar = new javax.swing.JButton();
        txtcodigoo = new javax.swing.JTextField();
        txtemail = new javax.swing.JTextField();
        txtnovasenha = new javax.swing.JTextField();
        confirmarsenha = new javax.swing.JTextField();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Labelerrosenha.setText("Insira as senhas iguais corretamente");
        jPanel1.add(Labelerrosenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 360, -1, -1));

        labelerro.setText("Insira o código de verificação certo");
        jPanel1.add(labelerro, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 240, -1, -1));

        labelerroemail.setText("Insira um email válido");
        jPanel1.add(labelerroemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 170, -1, -1));

        volrar.setText("Voltar");
        volrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                volrarMousePressed(evt);
            }
        });
        jPanel1.add(volrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 410, -1, -1));

        txtcodigoo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtcodigooKeyPressed(evt);
            }
        });
        jPanel1.add(txtcodigoo, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 210, 200, -1));

        txtemail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtemailKeyPressed(evt);
            }
        });
        jPanel1.add(txtemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 370, -1));

        txtnovasenha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtnovasenhaKeyPressed(evt);
            }
        });
        jPanel1.add(txtnovasenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 270, 300, -1));

        confirmarsenha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                confirmarsenhaKeyPressed(evt);
            }
        });
        jPanel1.add(confirmarsenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 330, 190, -1));
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtemailKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtemailKeyPressed
        if (evt.getKeyCode() == 10) {
            verificacaosenha();
        }
    }//GEN-LAST:event_txtemailKeyPressed

    private void txtcodigooKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcodigooKeyPressed
        if (evt.getKeyCode() == 10) {
            verificasenha2();
        }
    }//GEN-LAST:event_txtcodigooKeyPressed

    private void volrarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_volrarMousePressed
        LoginUsuario voltaproLogin = new LoginUsuario(dados);
        voltaproLogin.setVisible(true);
        dispose();


    }//GEN-LAST:event_volrarMousePressed

    private void txtnovasenhaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnovasenhaKeyPressed
        if (evt.getKeyCode() == 10) {
            confirmarsenha.requestFocus();
        }

    }//GEN-LAST:event_txtnovasenhaKeyPressed

    private void confirmarsenhaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_confirmarsenhaKeyPressed
        if (evt.getKeyCode() == 10) {
            if (txtnovasenha.getText().equals(confirmarsenha.getText())) {
                String senha = confirmarsenha.getText();
                controla.atualizaSenha(senha, txtemail.getText());
                dados.setSenha(senha);

            } else {
                Labelerrosenha.setVisible(true);
            }
        }
    }//GEN-LAST:event_confirmarsenhaKeyPressed
    private void baixando() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\esquecisenha.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(524, 462, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(esquecisenha.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(esquecisenha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(esquecisenha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(esquecisenha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(esquecisenha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new esquecisenha().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Labelerrosenha;
    private javax.swing.JTextField confirmarsenha;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelerro;
    private javax.swing.JLabel labelerroemail;
    private javax.swing.JTextField txtcodigoo;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtnovasenha;
    private javax.swing.JButton volrar;
    // End of variables declaration//GEN-END:variables

}
