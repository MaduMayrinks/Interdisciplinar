package com.javaandpgsql.telas;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class sobreCYP extends javax.swing.JFrame {

    public sobreCYP() {
        initComponents();
        setTitle("CYP");
        baixando();
        this.setLocationRelativeTo(null);

    }

    private void baixando() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\sobreoCYP.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1490, 720, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(sobreCYP.class.getName()).log(Level.SEVERE, null, ex);

        }
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\voltar (1).png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(300, 200, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                voltar.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(sobreCYP.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        voltar = new javax.swing.JLabel();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        voltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                voltarMousePressed(evt);
            }
        });
        jPanel1.add(voltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, 530, 180, 140));

        fotofundo.setIcon(new javax.swing.ImageIcon("C:\\Users\\0068957\\Downloads\\interdisciplinar-master\\interdisciplinar-master\\src\\main\\java\\com\\javaandpgsql\\imagem\\sobreoCYP.png")); // NOI18N
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1250, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void voltarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_voltarMousePressed
        JanelaPrincipal redirecionar = new JanelaPrincipal();
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_voltarMousePressed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new sobreCYP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel fotofundo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel voltar;
    // End of variables declaration//GEN-END:variables
}
