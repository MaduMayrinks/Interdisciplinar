package com.javaandpgsql.telas;

import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class ImagemComunidade extends javax.swing.JFrame {

    Comunidade dadosRecebidos;
    CadastroComunidade redirecionar;
    private Usuarios dadosUsuarios;

    public ImagemComunidade() {
        initComponents();
        baixaImagemfundoLUA();
        this.setLocationRelativeTo(null);
    }

    public ImagemComunidade(Comunidade Recebedados) {
        initComponents();
        baixaImagemfundoLUA();
        this.setLocationRelativeTo(null);
        dadosRecebidos = Recebedados;
    }

    private void baixaImagemfundoLUA() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\InsiraImagemComunidade.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(524, 462, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                jLabel1.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        voltar = new javax.swing.JLabel();
        salvarbtn = new javax.swing.JButton();
        Urltxt = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        voltar.setForeground(new java.awt.Color(102, 204, 255));
        voltar.setText("Voltar");
        voltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                voltarMousePressed(evt);
            }
        });
        jPanel1.add(voltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 400, 60, 10));

        salvarbtn.setText("Salvar");
        salvarbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salvarbtnActionPerformed(evt);
            }
        });
        jPanel1.add(salvarbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 360, 200, 20));
        jPanel1.add(Urltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 390, 30));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 470));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void salvarbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salvarbtnActionPerformed

        if (!Urltxt.getText().isEmpty()) {
            dadosRecebidos.setImagem(Urltxt.getText());
            redirecionar = new CadastroComunidade(dadosRecebidos);
            redirecionar.setDadosUsuarios(dadosUsuarios);
            redirecionar.setUrlImagem(this.Urltxt.getText());
            redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            redirecionar.setVisible(true);
            dispose();
        } else {
            String caminho = System.getProperty("user.dir");
            dadosRecebidos.setImagem(caminho
                    + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\luaIcon.PNG");
            String foto = caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\luaIcon.PNG";
            redirecionar = new CadastroComunidade(dadosRecebidos);
            redirecionar.setDadosUsuarios(dadosUsuarios);
            redirecionar.setUrlImagem(foto);
            redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            redirecionar.setVisible(true);
        }
    }//GEN-LAST:event_salvarbtnActionPerformed

    private void voltarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_voltarMousePressed
         //voltando para tela CadastroComunidade e reenviando os dados do usuario(Atualizados ou não) 
        if (!Urltxt.getText().isEmpty()) {
            dadosRecebidos.setImagem(Urltxt.getText());
            redirecionar = new CadastroComunidade(dadosRecebidos);
            redirecionar.setDadosUsuarios(dadosUsuarios);
            redirecionar.setUrlImagem(this.Urltxt.getText());
            redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            redirecionar.setVisible(true);
            dispose();
        } else {
            String caminho = System.getProperty("user.dir");
            dadosRecebidos.setImagem(caminho
                    + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\luaIcon.PNG");
            String foto = caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\luaIcon.PNG";
            redirecionar = new CadastroComunidade(dadosRecebidos);
            redirecionar.setDadosUsuarios(dadosUsuarios);
            redirecionar.setUrlImagem(foto);
            redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            redirecionar.setVisible(true);
        }

    }//GEN-LAST:event_voltarMousePressed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ImagemComunidade().setVisible(true);
            }
        });
    }

    public Comunidade getDadosRecebidos() {
        return dadosRecebidos;
    }

    public void setDadosRecebidos(Comunidade dadosRecebidos) {
        this.dadosRecebidos = dadosRecebidos;
    }

    public Usuarios getDadosUsuarios() {
        return dadosUsuarios;
    }

    public void setDadosUsuarios(Usuarios dadosUsuarios) {
        this.dadosUsuarios = dadosUsuarios;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Urltxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton salvarbtn;
    private javax.swing.JLabel voltar;
    // End of variables declaration//GEN-END:variables
}
