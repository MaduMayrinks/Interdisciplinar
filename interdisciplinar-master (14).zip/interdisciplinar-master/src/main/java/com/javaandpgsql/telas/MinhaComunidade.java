package com.javaandpgsql.telas;

import Controll.ControllerComunidade;
import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MinhaComunidade extends javax.swing.JFrame {

    ControllerComunidade controlando = new ControllerComunidade();
    ControllerUsuarios controllerUsu = new ControllerUsuarios();
    Comunidade dados = new Comunidade();
    Usuarios DadosUsuario;

    private String nome = " ";
    private String genero = " ";
    private int idade = -1;
    private String desc = " ";
    private String imagem = " ";
     public boolean FECHANDO_PELO_MENU = true;
    private JFrame frame;
    private int voltar;

    public MinhaComunidade(Comunidade ComunidadeSelected, Usuarios dadosRecebidos) {
        this(); //carregar o JFrame...
        setTitle("CYP");
        frame = this;
        VerificaFechamento();
        this.dados = ComunidadeSelected;
        this.DadosUsuario = dadosRecebidos;
        MudandoLabels();
        baixaImagem(this.dados);
    }

    public MinhaComunidade() {
        initComponents();
        setTitle("CYP");
        frame = this;
        VerificaFechamento();
        baixaImagemfundoLUA();
        this.setLocationRelativeTo(null);

        txtDesc.setVisible(false);
        txtGenero.setVisible(false);
        txtIdade.setVisible(false);
        jScrollPane1.setVisible(false);
        txtnomeComu.setVisible(false);

        confirmaDesc.setVisible(false);
        confirmaGene.setVisible(false);
        confirmaIdade.setVisible(false);
        confirmaNome.setVisible(false);
        baixaImagem(this.dados);
    }

    private void baixaImagemfundoLUA() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\MinhaComunidade.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1024, 576, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\SALVAR.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(310, 310, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                salvarDados.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);

        }
        
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\voltar (1).png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(300, 169, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                labelvoltar.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public void MudandoLabels() {
        nomeCom.setText(dados.getNome());
        descCom.setText(dados.getDescricao());
        generoCom.setText(dados.getGenero());
        idadeCom.setText(String.valueOf(dados.getRecomenda_idade()));
        fotoCom.setText(dados.getImagem());

        int tagC = dados.getTag();
        tag.setText("#" + String.valueOf(tagC));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        editar = new javax.swing.JLabel();
        labelvoltar = new javax.swing.JLabel();
        editarComuni = new javax.swing.JLabel();
        editarGene = new javax.swing.JLabel();
        editarIdade = new javax.swing.JLabel();
        editarDesc = new javax.swing.JLabel();
        txtnomeComu = new javax.swing.JTextField();
        txtGenero = new javax.swing.JTextField();
        txtIdade = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDesc = new javax.swing.JTextArea();
        nomeCom = new javax.swing.JLabel();
        generoCom = new javax.swing.JLabel();
        descCom = new javax.swing.JLabel();
        idadeCom = new javax.swing.JLabel();
        confirmaNome = new javax.swing.JLabel();
        confirmaGene = new javax.swing.JLabel();
        confirmaIdade = new javax.swing.JLabel();
        confirmaDesc = new javax.swing.JLabel();
        linhadebaixo1 = new javax.swing.JLabel();
        linhadebaixo2 = new javax.swing.JLabel();
        linhadebaixo3 = new javax.swing.JLabel();
        salvarDados = new javax.swing.JLabel();
        fotoCom = new javax.swing.JLabel();
        tag = new javax.swing.JLabel();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        editar.setText("     Editar  ");
        editar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarMousePressed(evt);
            }
        });
        jPanel1.add(editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 330, 60, -1));

        labelvoltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                labelvoltarMousePressed(evt);
            }
        });
        jPanel1.add(labelvoltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(-70, 440, 170, 140));

        editarComuni.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        editarComuni.setText("✎");
        editarComuni.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarComuniMousePressed(evt);
            }
        });
        jPanel1.add(editarComuni, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 140, 40, 40));

        editarGene.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        editarGene.setText("✎");
        editarGene.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarGeneMousePressed(evt);
            }
        });
        jPanel1.add(editarGene, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 200, 40, 40));

        editarIdade.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        editarIdade.setText("✎");
        editarIdade.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarIdadeMousePressed(evt);
            }
        });
        jPanel1.add(editarIdade, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, 40, 40));

        editarDesc.setFont(new java.awt.Font("DialogInput", 0, 18)); // NOI18N
        editarDesc.setText("✎");
        editarDesc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarDescMousePressed(evt);
            }
        });
        jPanel1.add(editarDesc, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 330, 40, 40));
        jPanel1.add(txtnomeComu, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 160, 180, -1));
        jPanel1.add(txtGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, 250, -1));
        jPanel1.add(txtIdade, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 280, 270, -1));

        txtDesc.setColumns(20);
        txtDesc.setRows(5);
        jScrollPane1.setViewportView(txtDesc);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 290, 60));

        nomeCom.setText("exemplo");
        jPanel1.add(nomeCom, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, -1, -1));

        generoCom.setText("exemplo");
        jPanel1.add(generoCom, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, -1, -1));

        descCom.setBackground(new java.awt.Color(255, 102, 204));
        descCom.setText("exemplo exemplo exemplo exemplo exemplo");
        descCom.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(descCom, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 290, 90));

        idadeCom.setText("123456789");
        jPanel1.add(idadeCom, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 280, -1, -1));

        confirmaNome.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        confirmaNome.setText("✔");
        confirmaNome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                confirmaNomeMousePressed(evt);
            }
        });
        jPanel1.add(confirmaNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 150, 30, 40));

        confirmaGene.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        confirmaGene.setText("✔");
        confirmaGene.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                confirmaGeneMousePressed(evt);
            }
        });
        jPanel1.add(confirmaGene, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 210, 30, 40));

        confirmaIdade.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        confirmaIdade.setText("✔");
        confirmaIdade.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                confirmaIdadeMousePressed(evt);
            }
        });
        jPanel1.add(confirmaIdade, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 270, 30, 40));

        confirmaDesc.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        confirmaDesc.setText("✔");
        confirmaDesc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                confirmaDescMousePressed(evt);
            }
        });
        jPanel1.add(confirmaDesc, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 350, 30, 40));

        linhadebaixo1.setForeground(new java.awt.Color(255, 204, 0));
        linhadebaixo1.setText("_________________________");
        jPanel1.add(linhadebaixo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, 310, 20));

        linhadebaixo2.setForeground(new java.awt.Color(255, 204, 0));
        linhadebaixo2.setText("______________________________");
        jPanel1.add(linhadebaixo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, 270, 20));

        linhadebaixo3.setForeground(new java.awt.Color(255, 204, 0));
        linhadebaixo3.setText("__________________________________");
        jPanel1.add(linhadebaixo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 280, 310, 20));

        salvarDados.setText("Salvar");
        salvarDados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                salvarDadosMousePressed(evt);
            }
        });
        jPanel1.add(salvarDados, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 410, 250, 70));
        jPanel1.add(fotoCom, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 120, 130, 200));

        tag.setText("#");
        jPanel1.add(tag, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, 50, -1));
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 580));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void salvandoDados() {
        if (!imagem.isBlank()) {
            dados.setImagem(imagem);
        }
        if (!nome.isBlank()) {
            dados.setNome(nome);
        }
        if (!genero.isBlank()) {
            dados.setGenero(genero);
        }
        if (!desc.isBlank()) {
            dados.setDescricao(desc);
        }
        if (idade != -1) {
            dados.setRecomenda_idade(idade);
        }
        controlando = new ControllerComunidade();
        controlando.atualizandoComunide(dados);
    }

    private void baixaImagem(Comunidade selecionada) {
        URL novaURl;
        String imagemfoto = selecionada.getImagem();

        try {

            novaURl = new URL(imagemfoto);

            if (imagemfoto.startsWith("https") || imagemfoto.startsWith("http")) {

                BufferedImage imagemmmm = ImageIO.read(novaURl);
                ImageIcon imgI = new ImageIcon(imagemmmm);
                imgI.setImage(imgI.getImage().getScaledInstance(130, 200, 100));
                fotoCom.setIcon(imgI);

            } else {

                File filefoto = new File(imagemfoto);
                BufferedImage imagemmmm = ImageIO.read(filefoto);
                ImageIcon imgI = new ImageIcon(imagemmmm);
                imgI.setImage(imgI.getImage().getScaledInstance(130, 200, 100));
                fotoCom.setIcon(imgI);

            }

        } catch (MalformedURLException ex) {
            Logger.getLogger(MinhaComunidade.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MinhaComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    private void editarComuniMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarComuniMousePressed

        confirmaNome.setVisible(true);
        txtnomeComu.setVisible(true);
        linhadebaixo1.setVisible(false);
        nomeCom.setVisible(false);
        editarComuni.setVisible(false);
    }//GEN-LAST:event_editarComuniMousePressed

    private void editarGeneMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarGeneMousePressed

        confirmaGene.setVisible(true);
        txtGenero.setVisible(true);
        linhadebaixo2.setVisible(false);
        generoCom.setVisible(false);
        editarGene.setVisible(false);
    }//GEN-LAST:event_editarGeneMousePressed

    private void editarIdadeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarIdadeMousePressed

        confirmaIdade.setVisible(true);
        txtIdade.setVisible(true);
        linhadebaixo3.setVisible(false);
        idadeCom.setVisible(false);
        editarIdade.setVisible(false);
    }//GEN-LAST:event_editarIdadeMousePressed

    private void editarDescMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarDescMousePressed

        confirmaDesc.setVisible(true);
        txtDesc.setVisible(true);
        jScrollPane1.setVisible(true);
        descCom.setVisible(false);
        editarDesc.setVisible(false);
    }//GEN-LAST:event_editarDescMousePressed

    private void confirmaNomeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmaNomeMousePressed

        if (txtnomeComu.getText().isBlank()) {
            nomeCom.setVisible(true);
            txtnomeComu.setVisible(false);
            linhadebaixo1.setVisible(true);
            confirmaNome.setVisible(false);
            editarComuni.setVisible(true);
        } else {
            //guardar no BD
            nomeCom.setText(txtnomeComu.getText());
            nomeCom.setVisible(true);
            txtnomeComu.setVisible(false);
            linhadebaixo1.setVisible(true);
            confirmaNome.setVisible(false);
            editarComuni.setVisible(true);
            nome = txtnomeComu.getText();
        }

    }//GEN-LAST:event_confirmaNomeMousePressed

    private void confirmaGeneMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmaGeneMousePressed

        if (txtGenero.getText().isBlank()) {
            generoCom.setVisible(true);
            txtGenero.setVisible(false);
            linhadebaixo2.setVisible(true);
            confirmaGene.setVisible(false);
            editarGene.setVisible(true);
        } else {
            //guardar no BD
            generoCom.setText(txtGenero.getText());
            generoCom.setVisible(true);
            txtGenero.setVisible(false);
            linhadebaixo2.setVisible(true);
            confirmaGene.setVisible(false);
            editarGene.setVisible(true);
            genero = txtGenero.getText();
        }
    }//GEN-LAST:event_confirmaGeneMousePressed

    private void confirmaIdadeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmaIdadeMousePressed

        if (txtIdade.getText().isBlank()) {
            idadeCom.setVisible(true);
            txtIdade.setVisible(false);
            linhadebaixo3.setVisible(true);
            confirmaIdade.setVisible(false);
            editarIdade.setVisible(true);
        } else {
            //guardar no BD
            txtIdade.setText(txtIdade.getText());
            idadeCom.setVisible(true);
            txtIdade.setVisible(false);
            linhadebaixo3.setVisible(true);
            confirmaIdade.setVisible(false);
            editarIdade.setVisible(true);
            idade = Integer.valueOf(txtIdade.getText());
        }
    }//GEN-LAST:event_confirmaIdadeMousePressed

    private void confirmaDescMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmaDescMousePressed

        if (txtDesc.getText().isBlank()) {
            descCom.setVisible(true);
            txtDesc.setVisible(false);
            confirmaDesc.setVisible(false);
            editarDesc.setVisible(true);
            jScrollPane1.setVisible(false);
        } else {
            //guardar no BD
            descCom.setText(txtDesc.getText());
            descCom.setVisible(true);
            txtDesc.setVisible(false);
            confirmaDesc.setVisible(false);
            editarDesc.setVisible(true);
            jScrollPane1.setVisible(false);
            desc = txtDesc.getText();
        }
    }//GEN-LAST:event_confirmaDescMousePressed

    private void salvarDadosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvarDadosMousePressed

        salvandoDados();
    }//GEN-LAST:event_salvarDadosMousePressed

    private void labelvoltarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelvoltarMousePressed
        // TODO add your handling code here:
        voltar++;
        ComunidadesUsuario redirecionar = new ComunidadesUsuario(DadosUsuario);
        redirecionar.setVisible(true);
        dispose();
    }
    private void VerificaFechamento() {
        //Aqui ele verifica se o usuario clicou para sair do programa
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                if(voltar<0){
                if (FECHANDO_PELO_MENU) {
                    int resposta
                            = JOptionPane.showConfirmDialog(null, "Você irá sair do programa, você tem certeza?", "Você tem certeza", JOptionPane.YES_NO_OPTION);
                    //Se o usuario quer fechar o programa
                    //ele o deixa offline
                    if (resposta == JOptionPane.YES_OPTION) {
                       
                        DadosUsuario.setEstado(0);
                        controllerUsu.updateEstadoUsuario(DadosUsuario);

                        dispose();
                    } else {
                        //Se não ele continua executando normalmente
                        frame.setVisible(true);

                    }
                }}
                FECHANDO_PELO_MENU = true;
            }
        });
    

    }//GEN-LAST:event_labelvoltarMousePressed

    private void editarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarMousePressed
        // TODO add your handling code here:
        editandoImagem imagemSetada = new editandoImagem(dados, DadosUsuario);
        imagemSetada.setVisible(true);
        dispose();
    }//GEN-LAST:event_editarMousePressed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MinhaComunidade().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel confirmaDesc;
    private javax.swing.JLabel confirmaGene;
    private javax.swing.JLabel confirmaIdade;
    private javax.swing.JLabel confirmaNome;
    private javax.swing.JLabel descCom;
    private javax.swing.JLabel editar;
    private javax.swing.JLabel editarComuni;
    private javax.swing.JLabel editarDesc;
    private javax.swing.JLabel editarGene;
    private javax.swing.JLabel editarIdade;
    private javax.swing.JLabel fotoCom;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JLabel generoCom;
    private javax.swing.JLabel idadeCom;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelvoltar;
    private javax.swing.JLabel linhadebaixo1;
    private javax.swing.JLabel linhadebaixo2;
    private javax.swing.JLabel linhadebaixo3;
    private javax.swing.JLabel nomeCom;
    private javax.swing.JLabel salvarDados;
    private javax.swing.JLabel tag;
    private javax.swing.JTextArea txtDesc;
    private javax.swing.JTextField txtGenero;
    private javax.swing.JTextField txtIdade;
    private javax.swing.JTextField txtnomeComu;
    // End of variables declaration//GEN-END:variables
}
