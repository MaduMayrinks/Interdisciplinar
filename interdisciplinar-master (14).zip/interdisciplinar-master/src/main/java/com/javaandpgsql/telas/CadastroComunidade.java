package com.javaandpgsql.telas;

import Controll.ControllerComunidade;
import Controll.ControllerGenero;
import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Generos;
import com.javaandpgsql.model.Usuarios;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CadastroComunidade extends javax.swing.JFrame {

    private String urlImagem;
    private String genero = " ";
    private int recomendaIdade = 12;
    private Comunidade dadosComunidade = new Comunidade();
    private Usuarios dadosUsuarios;
    private ImagemComunidade repassandoImagem;
    private ControllerComunidade controlerComunidade = new ControllerComunidade();
    private ControllerUsuarios controlando = new ControllerUsuarios();
    private ControllerGenero controlerGenero;
    private boolean FECHANDO_PELO_MENU = true;
    private int voltar = 0;
    private JFrame frame;


    public CadastroComunidade(Usuarios dados) {
        initComponents();
        setTitle("CYP");
        BaixarImagemCompts();
        this.dadosUsuarios = dados;
        this.setLocationRelativeTo(null);
        adicionarGenero.setVisible(false);
        labelErroNome.setVisible(false);
        novoGenero.setVisible(false);
        this.preencheComboBoxGeneros();
        frame = this;
        VerificaFechamento();
    }

    public CadastroComunidade(Comunidade dadosComunidade) {
        initComponents();
        setTitle("CYP");

        nometxt.setText(dadosComunidade.getNome());
        descricaotxt.setText(dadosComunidade.getDescricao());

        this.setLocationRelativeTo(null);
        BaixarImagemCompts();
        urlImagem = dadosComunidade.getImagem();
        baixaImagem();
        adicionarGenero.setVisible(false);
        labelErroNome.setVisible(false);
        novoGenero.setVisible(false);
        dadosComunidade.setImagem(dadosComunidade.getImagem());
        this.preencheComboBoxGeneros();
        frame = this;
        VerificaFechamento();
    }

    private CadastroComunidade() {
        initComponents();
        setTitle("CYP");
        this.setLocationRelativeTo(null);
        labelErroNome.setVisible(false);
        adicionarGenero.setVisible(false);
        novoGenero.setVisible(false);
        baixaImagem();
        BaixarImagemCompts();

        nometxt.setText(dadosComunidade.getNome());
        descricaotxt.setText(dadosComunidade.getDescricao());
        recomendacaoidadetxt.setText(String.valueOf(dadosComunidade.getRecomenda_idade()));
        this.preencheComboBoxGeneros();
    }

    private void voltarparacomunidade() {
        voltar++;
        dadosComunidade.setNome(nometxt.getText());
        dadosComunidade.setDescricao(descricaotxt.getText());
        repassandoImagem = new ImagemComunidade(dadosComunidade);
        repassandoImagem.setDadosRecebidos(dadosComunidade);
        repassandoImagem.setDadosUsuarios(dadosUsuarios);
        repassandoImagem.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        repassandoImagem.setVisible(true);
        dispose();
    }

    public void baixaImagem() {
        URL novaURl;
        File arq;
        try {
            if (urlImagem.startsWith("https") || urlImagem.startsWith("http")) {
                novaURl = new URL(urlImagem);
                BufferedImage imagemmmm = ImageIO.read(novaURl);
                ImageIcon imgI = new ImageIcon(imagemmmm);
                imgI.setImage(imgI.getImage().getScaledInstance(150, 210, 100));
                fotolabel.setIcon(imgI);
                dadosComunidade.setImagem(novaURl.getPath());
            } else {
                arq = new File(urlImagem);
                BufferedImage imagemmmm = ImageIO.read(arq);
                ImageIcon imgI = new ImageIcon(imagemmmm);
                imgI.setImage(imgI.getImage().getScaledInstance(150, 210, 100));
                fotolabel.setIcon(imgI);
                dadosComunidade.setImagem(arq.getPath());
            }
        } catch (MalformedURLException ex) {
            ex.printStackTrace();

        } catch (IOException ex) {
            Logger.getLogger(CadastroComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void BaixarImagemCompts() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\criarComunidade.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1490, 720, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fundoimagem.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(CadastroComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Baixar imagem de genero
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\adicionargenero.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(300, 169, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                Adicionargenero.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(CadastroComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Baixar imagem voltar
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\voltar (1).png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(300, 169, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                labelvoltar.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(CadastroComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

        //botão editar
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\editar.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(210, 210, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                editarLbl.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(CadastroComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

        //botao salvar
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\SALVAR.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(310, 310, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                salvarlbl.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(CadastroComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        confirmaNovaG = new javax.swing.JLabel();
        adicionarGenero = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        nometxt = new javax.swing.JTextField();
        labelErroNome = new javax.swing.JLabel();
        novoGenero = new javax.swing.JTextField();
        descricaoarea = new javax.swing.JScrollPane();
        descricaotxt = new javax.swing.JTextArea();
        recomendacaoidadetxt = new javax.swing.JTextField();
        salvarlbl = new javax.swing.JLabel();
        Adicionargenero = new javax.swing.JLabel();
        labelvoltar = new javax.swing.JLabel();
        editarLbl = new javax.swing.JLabel();
        fotolabel = new javax.swing.JLabel();
        fundoimagem = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        confirmaNovaG.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        confirmaNovaG.setForeground(new java.awt.Color(255, 204, 0));
        confirmaNovaG.setText("✔️");
        confirmaNovaG.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                confirmaNovaGMousePressed(evt);
            }
        });
        getContentPane().add(confirmaNovaG, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 280, -1, 40));

        adicionarGenero.setForeground(new java.awt.Color(255, 204, 0));
        adicionarGenero.setText("Adicionado com sucesso!");
        getContentPane().add(adicionarGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 320, -1, -1));

        jComboBox1.setBackground(new java.awt.Color(228, 184, 255));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos" }));
        jComboBox1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 250, 350, -1));
        getContentPane().add(nometxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 180, 380, -1));

        labelErroNome.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelErroNome.setForeground(new java.awt.Color(245, 20, 20));
        labelErroNome.setText("Insira o nome da comunidade!");
        getContentPane().add(labelErroNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 210, -1, -1));
        getContentPane().add(novoGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 290, 170, -1));

        descricaotxt.setColumns(20);
        descricaotxt.setRows(5);
        descricaoarea.setViewportView(descricaotxt);

        getContentPane().add(descricaoarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 340, 410, 190));

        recomendacaoidadetxt.setForeground(new java.awt.Color(153, 153, 153));
        recomendacaoidadetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        recomendacaoidadetxt.setText("12");
        recomendacaoidadetxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recomendacaoidadetxtMouseClicked(evt);
            }
        });
        getContentPane().add(recomendacaoidadetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 140, 80, -1));

        salvarlbl.setText("salvar");
        salvarlbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                salvarlblMousePressed(evt);
            }
        });
        getContentPane().add(salvarlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 600, 240, 70));

        Adicionargenero.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                AdicionargeneroMousePressed(evt);
            }
        });
        getContentPane().add(Adicionargenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 230, 290, 120));

        labelvoltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                labelvoltarMousePressed(evt);
            }
        });
        getContentPane().add(labelvoltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(-80, 620, 180, 80));

        editarLbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarLblMousePressed(evt);
            }
        });
        getContentPane().add(editarLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, 250, 90));

        fotolabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 0)));
        getContentPane().add(fotolabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 150, 210));
        getContentPane().add(fundoimagem, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1450, 710));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void recomendacaoidadetxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recomendacaoidadetxtMouseClicked
        // TODO add your handling code here:
        recomendacaoidadetxt.setText("");
        recomendacaoidadetxt.setEnabled(true);
        recomendacaoidadetxt.setForeground(Color.BLACK);
    }//GEN-LAST:event_recomendacaoidadetxtMouseClicked

    private void salvarlblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvarlblMousePressed
        //se ele inserir nada...
        voltar++;
        String imagem = "";
        if (nometxt.getText().isBlank() || descricaotxt.getText().isBlank()) {
            labelErroNome.setVisible(true);
        } else {

            if (this.urlImagem == null || this.urlImagem.equals("") || this.urlImagem.isBlank()) {
                imagem = "https://i.pinimg.com/originals/27/f1/e0/27f1e002b3be1508008372107bff1087.jpg";
            } else {
                imagem = urlImagem;
                dadosComunidade.setImagem(imagem);
            }

            String descri = descricaotxt.getText();

            if (!recomendacaoidadetxt.getText().isEmpty()) {
                recomendaIdade = Integer.parseInt(recomendacaoidadetxt.getText());
            } else {
                recomendaIdade = 12;
            }

            String nome = nometxt.getText();
            String nomeAdm = dadosUsuarios.getNomeUsuario();
            genero = (String) jComboBox1.getSelectedItem();
            Generos g = controlerGenero.consultaObjGenero(genero);

            int tag = controlerComunidade.TagComunidade(nome);

            dadosComunidade = new Comunidade(imagem, descri, recomendaIdade, nome, nomeAdm, tag, genero, dadosUsuarios.getTag());

            ComunidadesUsuario repassainformacao = new ComunidadesUsuario(dadosComunidade);

            //Gravando a comunidade no BD
            controlerComunidade.CadastrarComunidade(dadosComunidade);
            TelaPrincipal redirecionar = new TelaPrincipal(dadosComunidade, dadosUsuarios);
            redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            redirecionar.setVisible(true);
            dispose();
        }
    }//GEN-LAST:event_salvarlblMousePressed

    private void AdicionargeneroMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AdicionargeneroMousePressed
        // TODO add your handling code here:
        adicionarGenero.setVisible(false);
        novoGenero.setVisible(true);
        confirmaNovaG.setVisible(true);
    }//GEN-LAST:event_AdicionargeneroMousePressed

    private void labelvoltarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelvoltarMousePressed
   
        voltar++;
        TelaPrincipal redirecionar = new TelaPrincipal(dadosComunidade, dadosUsuarios);
        redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_labelvoltarMousePressed

    private void editarLblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarLblMousePressed

        voltarparacomunidade();
    }//GEN-LAST:event_editarLblMousePressed

    private void confirmaNovaGMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmaNovaGMousePressed

        controlerComunidade = new ControllerComunidade();

        if (controlerGenero.ConsultarSeGeneroExiste(novoGenero.getText())) {
            adicionarGenero.setText("Gênero já existente!");
            adicionarGenero.setVisible(true);
            novoGenero.setText("");
            novoGenero.setVisible(true);
            confirmaNovaG.setVisible(true);
        } else {
            if (novoGenero.getText().isBlank()) {
                adicionarGenero.setText("Nenhum gênero adicionado!");
                adicionarGenero.setVisible(true);
            } else {
                dadosComunidade.setGenero(novoGenero.getText());
                novoGenero.setEnabled(false);
                adicionarGenero.setText("Gênero adicionado!");
                adicionarGenero.setVisible(true);
                genero = novoGenero.getText();
                //jComboBox1.addItem(genero);
                confirmaNovaG.setVisible(false);
                //Insere o novo genero
                controlerGenero.InserirGenero(novoGenero.getText());
                //consultar/atualizar COMBOBOX
                this.preencheComboBoxGeneros();
            }
        }
    }//GEN-LAST:event_confirmaNovaGMousePressed
    public void preencheComboBoxGeneros() {
        controlerGenero = new ControllerGenero();
        List<Generos> lista = controlerGenero.RetornaTodosGeneros();
        this.jComboBox1.removeAllItems();
        for (Generos atual : lista) {
            this.jComboBox1.addItem(atual.getNome());
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroComunidade().setVisible(true);
            }
        });
    }
    private void VerificaFechamento() {
        //Aqui ele verifica se o usuario clicou para sair do programa
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                if(voltar<0){
                if (FECHANDO_PELO_MENU) {
                    int resposta
                            = JOptionPane.showConfirmDialog(null, "Você irá sair do programa, você tem certeza?", "Você tem certeza", JOptionPane.YES_NO_OPTION);
                    //Se o usuario quer fechar o programa
                    //ele o deixa offline
                    if (resposta == JOptionPane.YES_OPTION) {
                       
                        dadosUsuarios.setEstado(0);
                        controlando.updateEstadoUsuario(dadosUsuarios);

                        dispose();
                    } else {
                        //Se não ele continua executando normalmente
                        frame.setVisible(true);

                    }
                }}
                FECHANDO_PELO_MENU = true;
            }
        });
    }

    public String getUrlImagem() {
        return urlImagem;
    }

    public Usuarios getDadosUsuarios() {
        return dadosUsuarios;
    }

    public void setDadosUsuarios(Usuarios dadosUsuarios) {
        this.dadosUsuarios = dadosUsuarios;
    }

    public void setUrlImagem(String urlImagem) {
        this.urlImagem = urlImagem;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Adicionargenero;
    private javax.swing.JLabel adicionarGenero;
    private javax.swing.JLabel confirmaNovaG;
    private javax.swing.JScrollPane descricaoarea;
    private javax.swing.JTextArea descricaotxt;
    private javax.swing.JLabel editarLbl;
    private javax.swing.JLabel fotolabel;
    private javax.swing.JLabel fundoimagem;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel labelErroNome;
    private javax.swing.JLabel labelvoltar;
    private javax.swing.JTextField nometxt;
    private javax.swing.JTextField novoGenero;
    private javax.swing.JTextField recomendacaoidadetxt;
    private javax.swing.JLabel salvarlbl;
    // End of variables declaration//GEN-END:variables
}
