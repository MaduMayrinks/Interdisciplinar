package com.javaandpgsql.telas;

import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Usuarios;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class CadastroUsuario extends javax.swing.JFrame {

    public CadastroUsuario() {
        initComponents();
        baixaImagemfundoLUA();

        setTitle("CYP");

        labelErro.setVisible(false);
        this.setLocationRelativeTo(null);
        try {
            this.jPanel1 = new CadastroUsuario.FonteRButton(this.femRadio);
            this.jPanel1 = new CadastroUsuario.FonteRButton(this.mascRadio);
            this.jPanel1 = new CadastroUsuario.FonteRButton(this.outroRadio);
            this.jPanel1 = new CadastroUsuario.FonteLabel(this.labelErro);
            this.jPanel1 = new CadastroUsuario.FonteLabel(this.logar);
            this.jPanel1 = new CadastroUsuario.FonteLabel(this.contaexistente);
            this.jPanel1 = new CadastroUsuario.FonteBoton(this.cadastrarBtn);
        } catch (Exception ex) {
            Logger.getLogger(CadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        avisoSenha.setVisible(false);
        AvisoIdade.setVisible(false);
        fecharaviso.setVisible(false);

    }
    // Configurar as cores desejadas

    private static ImageIcon resizeIcon(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image resizedImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImg);
    }

    public class FonteRButton extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteRButton(JRadioButton anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 11);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public class FonteLabel extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteLabel(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 11);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public class FonteBoton extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteBoton(JButton anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 19);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        fecharaviso = new javax.swing.JLabel();
        avisoSenha = new javax.swing.JLabel();
        femRadio = new javax.swing.JRadioButton();
        mascRadio = new javax.swing.JRadioButton();
        outroRadio = new javax.swing.JRadioButton();
        txtEmail = new javax.swing.JTextField();
        txtSenha = new javax.swing.JPasswordField();
        txtNome = new javax.swing.JTextField();
        labelErro = new javax.swing.JLabel();
        txtIdade = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        cadastrarBtn = new javax.swing.JButton();
        mostrarSenha = new javax.swing.JButton();
        contaexistente = new javax.swing.JLabel();
        logar = new javax.swing.JLabel();
        txtNomeUsuario = new javax.swing.JTextField();
        labelerroformato = new javax.swing.JLabel();
        AvisoIdade = new javax.swing.JLabel();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro de Alunos");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(78, 43, 182));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fecharaviso.setText("X");
        fecharaviso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                fecharavisoMousePressed(evt);
            }
        });
        jPanel2.add(fecharaviso, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 470, 30, 30));
        jPanel2.add(avisoSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 250, 330, 20));

        femRadio.setForeground(new java.awt.Color(228, 184, 255));
        femRadio.setText("Fem");
        femRadio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel2.add(femRadio, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 460, -1, 20));

        mascRadio.setForeground(new java.awt.Color(228, 184, 255));
        mascRadio.setText("Masc");
        mascRadio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel2.add(mascRadio, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 460, -1, 20));

        outroRadio.setForeground(new java.awt.Color(228, 184, 255));
        outroRadio.setText("Outro");
        outroRadio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel2.add(outroRadio, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 460, -1, 20));

        txtEmail.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel2.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 150, 330, -1));
        jPanel2.add(txtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 230, 330, -1));
        jPanel2.add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 300, 280, -1));

        labelErro.setForeground(new java.awt.Color(255, 63, 63));
        labelErro.setText("Erro! Email em uso...");
        jPanel2.add(labelErro, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 180, 120, -1));

        txtIdade.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel2.add(txtIdade, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 450, 110, -1));

        jLabel1.setText("🛈");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jLabel1MouseReleased(evt);
            }
        });
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 470, 20, 40));

        cadastrarBtn.setBackground(new java.awt.Color(51, 51, 51));
        cadastrarBtn.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        cadastrarBtn.setForeground(new java.awt.Color(228, 184, 255));
        cadastrarBtn.setText("Cadastrar!");
        cadastrarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarBtnActionPerformed(evt);
            }
        });
        jPanel2.add(cadastrarBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 540, 180, 40));

        mostrarSenha.setBackground(new java.awt.Color(51, 51, 51));
        mostrarSenha.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        mostrarSenha.setForeground(new java.awt.Color(228, 184, 255));
        mostrarSenha.setText("👁️");
        mostrarSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarSenhaActionPerformed(evt);
            }
        });
        jPanel2.add(mostrarSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 230, 60, 30));

        contaexistente.setText("Já tem uma conta?");
        jPanel2.add(contaexistente, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 590, -1, -1));

        logar.setForeground(new java.awt.Color(228, 184, 255));
        logar.setText("Login");
        logar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                logarMousePressed(evt);
            }
        });
        jPanel2.add(logar, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 590, 40, -1));
        jPanel2.add(txtNomeUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 380, 290, -1));

        labelerroformato.setForeground(new java.awt.Color(255, 63, 63));
        jPanel2.add(labelerroformato, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 180, 220, 20));
        jPanel2.add(AvisoIdade, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 480, 110, 110));
        jPanel2.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1220, 620));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 1220, 620));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1410, 710));

        pack();
    }// </editor-fold>//GEN-END:initComponents
        public boolean verificaSenha() {
        String senha = (new String(txtSenha.getPassword()));

        int comprimentoMaximo = 12;
        int numerosMinimos = 6;

        // Verifica se a senha atende ao comprimento máximo
        if (senha.length() >= numerosMinimos) {
            if (senha.length() <= comprimentoMaximo) {

                boolean temMaiuscula = false;
                boolean temSimboloEspecial = false;

                // Verifica cada caractere na senha
                for (char c : senha.toCharArray()) {
                    if (Character.isUpperCase(c)) {
                        temMaiuscula = true;
                    } else if (!Character.isLetterOrDigit(c)) {
                        temSimboloEspecial = true;
                    }
                }

                // Verifica se atende aos critérios
                if (temMaiuscula == true && temSimboloEspecial == true) {
                    avisoSenha.setVisible(false);
                    return true;
                } else {
                    String caminho = System.getProperty("user.home");
                    String iconPath = caminho + "\\src\\imagens\\4fcaf80db6845d97077fc69443c9df25.jpg";
                    ImageIcon originalIcon = new ImageIcon(iconPath);
                    ImageIcon resizedIcon = resizeIcon(originalIcon, 40, 40);

                    JOptionPane.showMessageDialog(
                            null,
                            "A senha deve ter pelo menos " + numerosMinimos
                            + " número(s), pelo menos 1 letra maiúscula, "
                            + "pelo menos 1 símbolo especial e não ultrapassar "
                            + comprimentoMaximo + " caracteres.",
                            "Erro de senha",
                            JOptionPane.INFORMATION_MESSAGE,
                            resizedIcon
                    );
                }
            } else {
                avisoSenha.setText("A senha não pode ultrapassar " + comprimentoMaximo + " digitos.");
                avisoSenha.setVisible(true);
            }

        } else {
            avisoSenha.setText("A senha deve ter no mínimo 6 digitos");
            avisoSenha.setVisible(true);
        }
        return false;
    }

    private void cadastrarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarBtnActionPerformed

        if (txtEmail.getText().isEmpty()
                || txtIdade.getText().isEmpty()
                || txtNome.getText().isEmpty() || txtNomeUsuario.getText().isEmpty()
                || (new String(txtSenha.getPassword())).isEmpty()) {
            JOptionPane.showMessageDialog(null, "Preencha todos os componentes!", "Erro de inserção", JOptionPane.ERROR_MESSAGE);

        } else {
            if (txtEmail.getText().endsWith("@outlook.com") || txtEmail.getText().endsWith("@gmail.com") || txtEmail.getText().endsWith("@hotmail.com")) {
                verificaSenha();
                if (verificaSenha() == true) {
                    Random gerador = new Random();
                    Usuarios dadosUsuario = new Usuarios();
                    dadosUsuario.setNome(txtNome.getText());

                    ControllerUsuarios controlando = new ControllerUsuarios();

                    //Verificando se o email do usuario já existe, utiliando o controler
                    if (controlando.verificaEmail(txtEmail.getText()) == false) { //se for false é porque não existe...

                        //Mandando os dados do usuario para o servico usuarios. Para que ele possa executar o gravar
                        int idade = (Integer.parseInt(txtIdade.getText()));
                        String nome = txtNome.getText();
                        String email = (txtEmail.getText());

                        String senha = (new String(txtSenha.getPassword()));

                        String nomeUsuario = (txtNomeUsuario.getText());
                        int algo = gerador.nextInt(1000, 9000);
                        int codigo = algo;
                        //imagem básica... (usuario)

                        String caminho = System.getProperty("user.home");

                        File arquivoVerificacaoEmail = new File(caminho + "\\Desktop\\verificacaoemailcadastro.txt");
                        System.out.println(caminho);
                        try {

                            arquivoVerificacaoEmail.createNewFile();
                            FileWriter escrita = new FileWriter(arquivoVerificacaoEmail, false);
                            BufferedWriter bufEscrita = new BufferedWriter(escrita);
                            String TranformaGerador = String.valueOf(algo);
                            bufEscrita.write("Insira seu código de Verificação: " + "\n");
                            bufEscrita.write(TranformaGerador + "\n");

                            bufEscrita.flush();
                            bufEscrita.close();

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        UIManager.put("OptionPane.background", new Color(78, 43, 182));
                        UIManager.put("Panel.background", new Color(78, 43, 182));
                        UIManager.put("OptionPane.messageForeground", Color.WHITE);

                        // Use o caminho absoluto para o ícone (substitua pelo caminho real da sua imagem)
                        String iconPath = caminho + "\\src\\imagens\\4fcaf80db6845d97077fc69443c9df25.jpg";
                        ImageIcon originalIcon = new ImageIcon(iconPath);
                        ImageIcon resizedIcon = resizeIcon(originalIcon, 40, 40);
                        // Exibir o JOptionPane.showInputDialog personalizado
                        String userInput = (String) JOptionPane.showInputDialog(
                                null,
                                "O código de verificação está na sua área de trabalho:",
                                "Verificação de email",
                                JOptionPane.INFORMATION_MESSAGE,
                                resizedIcon,
                                null,
                                ""
                        );
                        // Exibir a entrada do usuário (ou cancelamento)
                        if (userInput != null && !userInput.isEmpty()) {
                            JOptionPane.showMessageDialog(
                                    null,
                                    "Você digitou: " + userInput,
                                    "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE,
                                    resizedIcon
                            );
                        } else {
                            JOptionPane.showMessageDialog(
                                    null,
                                    "Operação cancelada",
                                    "Aviso",
                                    JOptionPane.WARNING_MESSAGE,
                                    resizedIcon
                            );
                        }

                        int transformanumero = Integer.parseInt(userInput);

                        if (transformanumero != algo) {

                            userInput = (String) JOptionPane.showInputDialog(
                                    null,
                                    "Insira o código de Verificação:",
                                    "Verificação de email",
                                    JOptionPane.INFORMATION_MESSAGE,
                                    resizedIcon,
                                    null,
                                    ""
                            );

                            transformanumero = Integer.parseInt(userInput);
                        }
                        if (transformanumero == algo) {
                            String genero = " ";
                            if (femRadio.isSelected()) {
                                genero = "fem";
                            } else if (mascRadio.isSelected()) {
                                genero = "masc";
                            } else if (outroRadio.isSelected()) {
                                genero = "outro";
                            }

                            arquivoVerificacaoEmail.delete();
                            String imagem = ("https://i.pinimg.com/originals/f5/98/b4/f598b4de6092c71b96a3fd12cf1ecb43.jpg");
                            int tag = controlando.retornandoTag(email, senha);
                            dadosUsuario = new Usuarios(idade, nome, email, senha, genero, nomeUsuario, codigo, imagem, tag, 1);
                            //Chamando o gravar usuarios no banco
                            controlando.cadastrarUsuarios(dadosUsuario);

                            //tag do usuario
                            //Repassando o usuario para o construtor, para manuseiarmos esses dados no código.
                            //Chamando a principal rainha( que é a tela das comunidades e etc) para redirecionar a tela
                            //E passando os dados do usuario para armazena los em minha conta
                            TelaPrincipal redirecionar = new TelaPrincipal(dadosUsuario);
                            redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                            redirecionar.setVisible(true);
                            dispose();
                        }
                    } else {
                        labelErro.setVisible(true);
                    }

                }

            } else {
                labelerroformato.setText("Insira um formato de email inválido");
            }

        }
    }//GEN-LAST:event_cadastrarBtnActionPerformed

    private void logarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logarMousePressed
        // TODO add your handling code here:
        LoginUsuario redirecionar = new LoginUsuario();
        redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_logarMousePressed

    private void mostrarSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarSenhaActionPerformed
        // TODO add your handling code here:
        if (txtSenha.getEchoChar() == '*') {
            txtSenha.setEchoChar((char) 0);
        } else {
            txtSenha.setEchoChar('*');
        }
    }//GEN-LAST:event_mostrarSenhaActionPerformed

    private void jLabel1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseReleased
        // TODO add your handling code here:
        AvisoIdade.setVisible(true);
        fecharaviso.setVisible(true);
    }//GEN-LAST:event_jLabel1MouseReleased

    private void fecharavisoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fecharavisoMousePressed
        AvisoIdade.setVisible(false);
        fecharaviso.setVisible(false);
    }//GEN-LAST:event_fecharavisoMousePressed
    private void baixaImagemfundoLUA() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\telacadastroteste.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1300, 628, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(CadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\insiraAviso.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(110, 110, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                AvisoIdade.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(CadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AvisoIdade;
    private javax.swing.JLabel avisoSenha;
    private javax.swing.JButton cadastrarBtn;
    private javax.swing.JLabel contaexistente;
    private javax.swing.JLabel fecharaviso;
    private javax.swing.JRadioButton femRadio;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel labelErro;
    private javax.swing.JLabel labelerroformato;
    private javax.swing.JLabel logar;
    private javax.swing.JRadioButton mascRadio;
    private javax.swing.JButton mostrarSenha;
    private javax.swing.JRadioButton outroRadio;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtIdade;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtNomeUsuario;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
