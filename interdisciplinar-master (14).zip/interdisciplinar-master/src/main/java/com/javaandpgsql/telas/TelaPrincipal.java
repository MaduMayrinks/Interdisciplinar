package com.javaandpgsql.telas;

import Controll.ControllerComunidade;
import Controll.ControllerGenero;
import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Chat;
import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Generos;
import com.javaandpgsql.model.Usuarios;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class TelaPrincipal extends javax.swing.JFrame {
//Variavel para mudar para conta do usuario

    private MinhaConta MinhaConta = new MinhaConta();

    //Dados do usuario
    private Usuarios dadosAtuais;

    //Repassando dados do usuario para comunidade , para não perder esses dados.
    private Comunidade repassandoDadosC;
    //Variavel para ir para a tela de cadastro da comunidade
    private CadastroComunidade chamarcomunidade;

    //Atualizando estado do usuario ( on, off)
    private Chat InformaçõesMensagemChat;

    private String Username;

    private String texto;

    private int cont = 0;

    //variavel que verifica se ele está fechando pelo menu
    public boolean FECHANDO_PELO_MENU = true;

    private JFrame frame;

    //Estado do úsuario 
    private int estado;

    private ControllerComunidade geracomunidades = new ControllerComunidade();
    private ControllerGenero generoController = new ControllerGenero();

    private ControllerUsuarios ServicoUser = new ControllerUsuarios();

    private DefaultListModel<List> listacomunidades = new DefaultListModel<>();
    private DefaultListModel<List> listatag = new DefaultListModel<>();
    private List comunidadeselecionada;
    private int PaginaAtual = 0;
    private String caminho = System.getProperty("user.home");
    private String iconPath = caminho + "\\src\\imagens\\4fcaf80db6845d97077fc69443c9df25.jpg";
    private ImageIcon originalIcon = new ImageIcon(iconPath);
    private ImageIcon resizedIcon = resizeIcon(originalIcon, 40, 40);

    public TelaPrincipal() {
        initComponents();
        setTitle("CYP");
        this.setLocationRelativeTo(null);
        frame = this;
        VerificaFechamento();
        baixarImagem();
        cantinhodaComunidadePaginada();

        try {
            this.jPanel1 = new TelaPrincipal.TesteFonte(this.criarcomunidade);
            this.jPanel1 = new TelaPrincipal.TesteFonte(this.comunidadesUsuarios);

        } catch (Exception ex) {
            Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        pesquisar.setEditable(false);
        panelpesquisar.setVisible(false);
    }

    public TelaPrincipal(Usuarios enviaDados) {
        initComponents();
        setTitle("CYP");
        baixarImagem();
        //Igualando a outra variavel para manuseiar os dados do usuario no código 
        dadosAtuais = enviaDados;
        frame = this;
        //Enviando dados do usuario para Minhaconta
        MinhaConta = new MinhaConta(enviaDados);
        this.setLocationRelativeTo(null);
        abreopcoesfundo.setVisible(false);
        VerificaFechamento();
        baixarImagemUsuario(enviaDados);
        cantinhodaComunidadePaginada();

        try {
            this.jPanel1 = new TelaPrincipal.TesteFonte(this.criarcomunidade);
            this.jPanel1 = new TelaPrincipal.TesteFonte(this.comunidadesUsuarios);

        } catch (Exception ex) {
            Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        pesquisar.setEditable(false);
        panelpesquisar.setVisible(false);
    }

    public TelaPrincipal(Comunidade pegandoDadosC, Usuarios pegandoDadosU) {
        initComponents();
        setTitle("CYP");

        frame = this;
        this.setLocationRelativeTo(null);

        this.dadosAtuais = pegandoDadosU;
        this.repassandoDadosC = pegandoDadosC;

        baixarImagem();
        baixarImagemUsuario(pegandoDadosU);
        cantinhodaComunidadePaginada();
        VerificaFechamento();
        //Adc();
        try {
            this.jPanel1 = new TelaPrincipal.TesteFonte(this.criarcomunidade);
            this.jPanel1 = new TelaPrincipal.TesteFonte(this.comunidadesUsuarios);

        } catch (Exception ex) {
            Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        pesquisar.setEditable(false);
        panelpesquisar.setVisible(false);
    }

    public class FonteBotao extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public FonteBotao(JButton anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 12);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public class TesteFonte extends JPanel {

        JTextArea textArea;
        String texto = "Montserrat-Bold";

        public TesteFonte(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\Montserrat-Bold.otf"))
                    .deriveFont(Font.PLAIN, 12);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public Usuarios getDadosAtuais() {
        return dadosAtuais;
    }

    public void setDadosAtuais(Usuarios dadosAtuais) {
        this.dadosAtuais = dadosAtuais;
    }

    private static ImageIcon resizeIcon(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image resizedImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImg);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        paginafrentebtn = new javax.swing.JButton();
        movertrasbtn = new javax.swing.JButton();
        pesquisar = new javax.swing.JTextField();
        trespontos = new javax.swing.JLabel();
        abreopcoesfundo = new javax.swing.JPanel();
        criarcomunidade = new javax.swing.JLabel();
        comunidadesUsuarios = new javax.swing.JLabel();
        fotinha = new javax.swing.JLabel();
        MinhaContaLabel = new javax.swing.JLabel();
        lupapesquisar = new javax.swing.JLabel();
        filtrolbl = new javax.swing.JLabel();
        panelpesquisar = new javax.swing.JPanel();
        Xlbl = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListaNomes = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaGeneros = new javax.swing.JList<>();
        fotopesquisa = new javax.swing.JLabel();
        cantinhodacomunidade = new javax.swing.JPanel();
        fotofundo = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setMinimumSize(new java.awt.Dimension(1532, 805));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        paginafrentebtn.setBackground(new java.awt.Color(204, 153, 255));
        paginafrentebtn.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        paginafrentebtn.setText("🠖");
        paginafrentebtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        paginafrentebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paginafrentebtnActionPerformed(evt);
            }
        });
        jPanel1.add(paginafrentebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 740, 60, 30));

        movertrasbtn.setBackground(new java.awt.Color(204, 153, 255));
        movertrasbtn.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        movertrasbtn.setText("🠔");
        movertrasbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        movertrasbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                movertrasbtnActionPerformed(evt);
            }
        });
        jPanel1.add(movertrasbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 740, 60, 30));

        pesquisar.setForeground(new java.awt.Color(153, 153, 153));
        pesquisar.setText("Pesquisar...");
        pesquisar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pesquisarMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pesquisarMousePressed(evt);
            }
        });
        pesquisar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisarKeyPressed(evt);
            }
        });
        jPanel1.add(pesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, 260, -1));

        trespontos.setFont(new java.awt.Font("Dialog", 0, 48)); // NOI18N
        trespontos.setForeground(new java.awt.Color(228, 184, 255));
        trespontos.setText("☰");
        trespontos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                trespontosMousePressed(evt);
            }
        });
        jPanel1.add(trespontos, new org.netbeans.lib.awtextra.AbsoluteConstraints(1420, 20, 50, 50));

        abreopcoesfundo.setBackground(new java.awt.Color(255, 244, 204));
        abreopcoesfundo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        criarcomunidade.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        criarcomunidade.setForeground(new java.awt.Color(51, 51, 51));
        criarcomunidade.setText("Criar comunidade");
        criarcomunidade.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                criarcomunidadeMousePressed(evt);
            }
        });
        abreopcoesfundo.add(criarcomunidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        comunidadesUsuarios.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        comunidadesUsuarios.setForeground(new java.awt.Color(51, 51, 51));
        comunidadesUsuarios.setText("Minhas Comunidades");
        comunidadesUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                comunidadesUsuariosMousePressed(evt);
            }
        });
        abreopcoesfundo.add(comunidadesUsuarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 150, -1));

        jPanel1.add(abreopcoesfundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 90, 160, 290));

        fotinha.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 0)));
        fotinha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                fotinhaMousePressed(evt);
            }
        });
        jPanel1.add(fotinha, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 20, 50, 50));

        MinhaContaLabel.setForeground(new java.awt.Color(51, 51, 255));
        MinhaContaLabel.setText("Minha conta");
        MinhaContaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MinhaContaLabelMousePressed(evt);
            }
        });
        jPanel1.add(MinhaContaLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 10, 250, 70));

        lupapesquisar.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lupapesquisar.setText("🔎");
        jPanel1.add(lupapesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, 30, 40));

        filtrolbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        filtrolbl.setForeground(new java.awt.Color(255, 244, 204));
        filtrolbl.setText("Filtro");
        jPanel1.add(filtrolbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 20, -1, -1));

        panelpesquisar.setBackground(new java.awt.Color(221, 205, 244));
        panelpesquisar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Xlbl.setFont(new java.awt.Font("Malgun Gothic", 0, 14)); // NOI18N
        Xlbl.setText("X");
        Xlbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                XlblMousePressed(evt);
            }
        });
        panelpesquisar.add(Xlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 10, 30, 30));

        ListaNomes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ListaNomesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(ListaNomes);

        panelpesquisar.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, 170, 280));

        jScrollPane2.setViewportView(listaGeneros);

        panelpesquisar.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 80, 170, 280));
        panelpesquisar.add(fotopesquisa, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 480, 390));

        jPanel1.add(panelpesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 480, 390));

        cantinhodacomunidade.setBackground(new java.awt.Color(98, 62, 171));

        javax.swing.GroupLayout cantinhodacomunidadeLayout = new javax.swing.GroupLayout(cantinhodacomunidade);
        cantinhodacomunidade.setLayout(cantinhodacomunidadeLayout);
        cantinhodacomunidadeLayout.setHorizontalGroup(
            cantinhodacomunidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        cantinhodacomunidadeLayout.setVerticalGroup(
            cantinhodacomunidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel1.add(cantinhodacomunidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, 990, 500));

        fotofundo.setIcon(new javax.swing.ImageIcon("C:\\Users\\0068962\\Downloads\\projetofinal\\interdisciplinar-master\\src\\main\\java\\com\\javaandpgsql\\imagem\\principaalrainha.png")); // NOI18N
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1500, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void baixarImagem() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\principaalrainha.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1532, 805, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);

        }

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\labelminhacontaoriginal.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(321, 91, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                MinhaContaLabel.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);

        }
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\pesquia.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(480, 390, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotopesquisa.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);

        }

    }

    private void baixarImagemUsuario(Usuarios dados) {
        URL novaURl;
        try {
            novaURl = new URL(dados.getImagem());
            BufferedImage imagemmmm = ImageIO.read(novaURl);
            ImageIcon imgI = new ImageIcon(imagemmmm);
            imgI.setImage(imgI.getImage().getScaledInstance(50, 50, 100));
            fotinha.setIcon(imgI);
        } catch (MalformedURLException ex) {
            Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    private void pesquisarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pesquisarMouseClicked
        panelpesquisar.setVisible(true);
        cantinhodacomunidade.setVisible(false);

        if (pesquisar.getText().equalsIgnoreCase("Pesquisar...")) {
            pesquisar.setEditable(true);
            pesquisar.setText("");
            pesquisar.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_pesquisarMouseClicked

    private void criarcomunidadeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_criarcomunidadeMousePressed
        chamarcomunidade = new CadastroComunidade(dadosAtuais);
        chamarcomunidade.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        chamarcomunidade.setVisible(true);
        Esconder();
    }//GEN-LAST:event_criarcomunidadeMousePressed

    private void comunidadesUsuariosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comunidadesUsuariosMousePressed
        ComunidadesUsuario rotacionandoinfo = new ComunidadesUsuario(dadosAtuais);
        rotacionandoinfo.setVisible(true);
        Esconder();
        dispose();
    }//GEN-LAST:event_comunidadesUsuariosMousePressed

    private void trespontosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trespontosMousePressed
        abreopcoesfundo.setVisible(true);
    }//GEN-LAST:event_trespontosMousePressed

    private void fotinhaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fotinhaMousePressed
        MinhaConta.setVisible(true);
        Esconder();
    }//GEN-LAST:event_fotinhaMousePressed

    private void MinhaContaLabelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinhaContaLabelMousePressed
        MinhaConta = new MinhaConta(dadosAtuais);
        MinhaConta.setVisible(true);
        Esconder();
    }//GEN-LAST:event_MinhaContaLabelMousePressed

    private void pesquisarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pesquisarMousePressed

        panelpesquisar.setVisible(true);
        cantinhodacomunidade.setVisible(false);

        if (pesquisar.getText().equalsIgnoreCase("Pesquisar...")) {
            pesquisar.setEditable(true);
            pesquisar.setText("");
            pesquisar.setForeground(Color.BLACK);
        }

    }//GEN-LAST:event_pesquisarMousePressed

    private void pesquisarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisarKeyPressed

        if (!(pesquisar.getText()).trim().equalsIgnoreCase("")) {
            List<Comunidade> lista = geracomunidades.ConsultaFiltro(pesquisar.getText());
            DefaultListModel dlm = new DefaultListModel();
            dlm.addAll(lista);
            ListaNomes.setModel(dlm);

            List<Generos> listaGenero = generoController.RetornaGenerosComFiltro(pesquisar.getText());
            DefaultListModel dlmGenero = new DefaultListModel();
            dlmGenero.addAll(listaGenero);

            listaGeneros.setModel(dlmGenero);
        }

    }//GEN-LAST:event_pesquisarKeyPressed

    private void ListaNomesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ListaNomesMouseClicked

        if (evt.getClickCount() >= 2) {
            Object selecionado = ListaNomes.getModel().getElementAt(ListaNomes.getSelectedIndex());
            Comunidade selecionada = (Comunidade) selecionado;
            String tagComunidade = String.valueOf(selecionada.getTag());
            TelaDentroComunidade telaAlteracaoComunidade = new TelaDentroComunidade(tagComunidade, dadosAtuais, selecionada.getNome());
            telaAlteracaoComunidade.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            telaAlteracaoComunidade.setVisible(true);
        }
    }//GEN-LAST:event_ListaNomesMouseClicked

    private void cantinhodaComunidadePaginada() {

        List<Comunidade> geraComunidades = geracomunidades.ComunidadeALL();
        int conta = geraComunidades.size() / 10;
        String convertetexto = String.valueOf(conta);
        // Calcula o total de páginas
        int totalPaginas = (int) Math.ceil((double) geraComunidades.size() / 10);

        // Verifica se é possível prosseguir para a próxima página
        if (PaginaAtual < totalPaginas) {
            // Aumenta a página atual
            PaginaAtual++;

            // Atualiza a interface
            cantinhodacomunidade.setLayout(new GridLayout(2, 4, 20, 40));
            cantinhodacomunidade.removeAll();

            // Itera sobre as comunidades da página atual
            for (Comunidade comunidade : geraComunidades.subList((PaginaAtual - 1) * 10, Math.min(PaginaAtual * 10, geraComunidades.size()))) {
                // Adiciona a comunidade à interface
                int tag = comunidade.getTag();
                cantinhodacomunidade.add(new ModelComunidade(tag, comunidade, dadosAtuais));
            }
        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "Página Inexistente",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE,
                    resizedIcon
            );
        }
    }

    public void setQntPagina(int qntPagina) {
        PaginaAtual = qntPagina;
        cantinhodaComunidadePaginada();
    }

    public void setQntPagina2(int qntPagina) {
        PaginaAtual = qntPagina;
        voltaPagina();
    }

    private void voltaPagina() {

        // Verifica se é possível voltar para a página anterior
        if (PaginaAtual > 1) {
            // Diminui a página atual
            PaginaAtual--;
            List<Comunidade> geraComunidades = geracomunidades.ComunidadeALL();

            // Atualiza a interface
            cantinhodacomunidade.setLayout(new GridLayout(2, 4, 20, 40));
            cantinhodacomunidade.removeAll();

            // Itera sobre as comunidades da página atual - 14
            for (Comunidade comunidade : geraComunidades.subList((PaginaAtual - 1) * 10, Math.min(PaginaAtual * 10, geraComunidades.size()))) {
                // Adiciona a comunidade à interface
                int tag = comunidade.getTag();
                cantinhodacomunidade.add(new ModelComunidade(tag, comunidade, dadosAtuais));
            }
        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "Página Inexistente",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE,
                    resizedIcon
            );
        }
    }

    private void paginafrentebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paginafrentebtnActionPerformed
        setQntPagina(PaginaAtual);
        this.repaint();
        //PaginaAtual++;
    }//GEN-LAST:event_paginafrentebtnActionPerformed

    private void XlblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_XlblMousePressed
        panelpesquisar.setVisible(false);
        cantinhodacomunidade.setVisible(true);
    }//GEN-LAST:event_XlblMousePressed

    private void movertrasbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_movertrasbtnActionPerformed
        setQntPagina2(PaginaAtual);
        this.repaint();
    }//GEN-LAST:event_movertrasbtnActionPerformed
    private void Adc() {

        List<Comunidade> lista = geracomunidades.ConsultaFiltro(pesquisar.getText());
        DefaultListModel dlm = new DefaultListModel();
        dlm.addAll(lista);
        ListaNomes.setModel(dlm);
    }

    private void VerificaFechamento() {
        //Aqui ele verifica se o usuario clicou para sair do programa
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                if (FECHANDO_PELO_MENU) {
                    int resposta
                            = JOptionPane.showConfirmDialog(null, "Você irá sair do programa, você tem certeza?", "Você tem certeza", JOptionPane.YES_NO_OPTION);
                    //Se o usuario quer fechar o programa
                    //ele o deixa offline
                    if (resposta == JOptionPane.YES_OPTION) {
                        estado = 0;
                        dadosAtuais.setEstado(estado);
                        ServicoUser.updateEstadoUsuario(dadosAtuais);

                        dispose();
                    } else {
                        //Se não ele continua executando normalmente
                        frame.setVisible(true);

                    }
                }
                FECHANDO_PELO_MENU = true;
            }
        });
    }

    private void Esconder() {
        FECHANDO_PELO_MENU = false;
        dispose();
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Usuarios enviaDados = null;
                new TelaPrincipal(enviaDados).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> ListaNomes;
    private javax.swing.JLabel MinhaContaLabel;
    private javax.swing.JLabel Xlbl;
    private javax.swing.JPanel abreopcoesfundo;
    private javax.swing.JPanel cantinhodacomunidade;
    private javax.swing.JLabel comunidadesUsuarios;
    private javax.swing.JLabel criarcomunidade;
    private javax.swing.JLabel filtrolbl;
    private javax.swing.JLabel fotinha;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JLabel fotopesquisa;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JList<String> listaGeneros;
    private javax.swing.JLabel lupapesquisar;
    private javax.swing.JButton movertrasbtn;
    private javax.swing.JButton paginafrentebtn;
    private javax.swing.JPanel panelpesquisar;
    private javax.swing.JTextField pesquisar;
    private javax.swing.JLabel trespontos;
    // End of variables declaration//GEN-END:variables
}
