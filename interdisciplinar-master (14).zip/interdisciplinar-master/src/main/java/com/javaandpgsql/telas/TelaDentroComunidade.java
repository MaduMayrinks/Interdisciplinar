package com.javaandpgsql.telas;

import Controll.ControllerChat;
import Controll.ControllerComunidade;
import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Chat;
import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;

public class TelaDentroComunidade extends javax.swing.JFrame {

    private ControllerComunidade ServicoComunidade = new ControllerComunidade();
    private ControllerChat ServicoChat = new ControllerChat();
    private int tagnova = 0;
    private DefaultListModel<String> UserON = new DefaultListModel<>();
    private DefaultListModel<String> Mensagens = new DefaultListModel<>();
    private Usuarios Meusdados;
    private String NomeC;
    private ControllerUsuarios ServicoUser = new ControllerUsuarios();
    private JFrame frame;

    public TelaDentroComunidade(String tag, Usuarios dados, String NomeComunidade) {
        initComponents();
        this.setLocationRelativeTo(null);
        setTitle("CYP");
        frame = this;
        setTitle(NomeComunidade);
        Meusdados = dados;
        NomeC = NomeComunidade;
        baixando();
        //Fonte
        tryComponentes();
        PegandoDadosComunidade(Integer.parseInt(tag));
        SegundoPlanoUsers();
        SegundoPlanoMSG();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private TelaDentroComunidade() {
        frame = this;
        setTitle("CYP");
        this.setLocationRelativeTo(null);
        baixando();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private void PegandoDadosComunidade(int tagComunidade) {
        Comunidade informacoesdentrochat = ServicoComunidade.SelecionaComunidade(tagComunidade);
        NomeDonoLabel.setText(informacoesdentrochat.getNomedono());
        labeldescricao.setText(informacoesdentrochat.getDescricao());
        Nomecomunidadelbl.setText(informacoesdentrochat.getNome());

    }

    private void tryComponentes() {
        try {
            this.jPanel1 = new TelaDentroComunidade.TesteFonte(this.NomeDonoLabel);
            this.jPanel1 = new TelaDentroComunidade.TesteFonte2(this.Nomecomunidadelbl);
            this.jPanel1 = new TelaDentroComunidade.TesteFonte3(this.labeldescricao);
        } catch (Exception ex) {
            Logger.getLogger(TelaDentroComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ListMSG = new javax.swing.JList<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListausuariosOnline = new javax.swing.JList<>();
        NomeDonoLabel = new javax.swing.JLabel();
        Nomecomunidadelbl = new javax.swing.JLabel();
        labeldescricao = new javax.swing.JLabel();
        txtchat = new javax.swing.JTextField();
        telafundi = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane2.setViewportView(ListMSG);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 160, 800, 390));

        jScrollPane1.setViewportView(ListausuariosOnline);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1260, 140, 160, 410));

        NomeDonoLabel.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        NomeDonoLabel.setForeground(new java.awt.Color(255, 255, 255));
        NomeDonoLabel.setText("hhh");
        jPanel1.add(NomeDonoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 170, 30));

        Nomecomunidadelbl.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Nomecomunidadelbl.setForeground(new java.awt.Color(255, 255, 255));
        Nomecomunidadelbl.setText("Nome");
        jPanel1.add(Nomecomunidadelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 50, -1, -1));

        labeldescricao.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labeldescricao.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(labeldescricao, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 200, 220));

        txtchat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtchatKeyPressed(evt);
            }
        });
        jPanel1.add(txtchat, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 620, 520, 30));
        jPanel1.add(telafundi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 720));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1490, 720));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtchatKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtchatKeyPressed
        if (evt.getKeyCode() == 10) {
            Chat Novochat = new Chat(tagnova, Meusdados.getNomeUsuario(), txtchat.getText(), NomeC);
            ServicoChat.Gravarchat(Novochat);
            txtchat.setText("");
        }
    }//GEN-LAST:event_txtchatKeyPressed

    public void SegundoPlanoUsers() {

        SwingWorker AtualizaOnline = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                while (true) {
                    //Adicionando os usuarios online na lista
                    List<Usuarios> lista = ServicoComunidade.USerONLista();
                    DefaultListModel OnLista = new DefaultListModel();
                    OnLista.addAll(lista);
                    ListausuariosOnline.setModel(OnLista);
                    Thread.sleep(1000);
                }
            }

        };
        AtualizaOnline.execute();
    }

    public void SegundoPlanoMSG() {

        SwingWorker AtualizaOnline = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                while (true) {
                    //Adicionando os usuarios online na lista
                    List<Chat> lista = ServicoChat.Mensagens(NomeC);
                    DefaultListModel MSGLista = new DefaultListModel();
                    MSGLista.addAll(lista);
                    ListMSG.setModel(MSGLista);
                    Thread.sleep(1000);
                }
            }

        };
        AtualizaOnline.execute();
    }

    private void baixando() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\Telachat.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1490, 720, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                telafundi.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(TelaDentroComunidade.class.getName()).log(Level.SEVERE, null, ex);

        }

    }

    public class TesteFonte extends JPanel {

        JTextArea textArea;
        String texto = "MontserratAlternates-Regular";

        public TesteFonte(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\MontserratAlternates-Regular.otf"))
                    .deriveFont(Font.PLAIN, 24);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public class TesteFonte2 extends JPanel {

        JTextArea textArea;
        String texto = "MontserratAlternates-Regular";

        public TesteFonte2(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\MontserratAlternates-Regular.otf"))
                    .deriveFont(Font.PLAIN, 36);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public class TesteFonte3 extends JPanel {

        JTextArea textArea;
        String texto = "MontserratAlternates-Regular";

        public TesteFonte3(JLabel anterior) throws Exception {

            super(new GridBagLayout());
            textArea = new JTextArea(5, 20);
            String caminho = System.getProperty("user.dir");
            Font minhaFonte = Font.createFont(Font.TRUETYPE_FONT,
                    new File(caminho + "\\src\\main\\java\\com\\javaandpgsql\\fonte\\MontserratAlternates-Regular.otf"))
                    .deriveFont(Font.PLAIN, 14);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(textArea, c);
            anterior.setFont(minhaFonte);
            textArea.setFont(minhaFonte);
            textArea.append(texto + "\n");
        }
    }

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaDentroComunidade.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaDentroComunidade.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaDentroComunidade.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaDentroComunidade.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaDentroComunidade().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> ListMSG;
    private javax.swing.JList<Usuarios> ListausuariosOnline;
    private javax.swing.JLabel NomeDonoLabel;
    private javax.swing.JLabel Nomecomunidadelbl;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel labeldescricao;
    private javax.swing.JLabel telafundi;
    private javax.swing.JTextField txtchat;
    // End of variables declaration//GEN-END:variables
}
