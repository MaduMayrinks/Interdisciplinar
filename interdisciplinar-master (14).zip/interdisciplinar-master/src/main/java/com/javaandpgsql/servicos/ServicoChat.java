package com.javaandpgsql.servicos;

import com.javaandpgsql.conexao.Conexao;
import com.javaandpgsql.model.Chat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ServicoChat {

    public void GravarMSG(Chat Dados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO CYP.chat(tag,nome,texto,comunidade) "
                    + " VALUES (?,?,?,?)returning tag;";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setInt(1, Dados.getTag());
            insercao.setString(2, Dados.getNome());
            insercao.setString(3, Dados.getTexto());
            insercao.setString(4, Dados.getComunidade());
            insercao.execute();
            ResultSet retorno = insercao.getGeneratedKeys();
            //insercao.executeUpdate();
            int tagInserida = 0;
            if (retorno.next()) {
                tagInserida = retorno.getInt("tag");
                Dados.setTag(tagInserida);
            }
            c.close();
            //return tagInserida;
        } catch (SQLException ex) {
            ex.printStackTrace();
            //return 0;
        }
    }

    public ArrayList<Chat> MensagensComunidade(String NomeComunidade) {

        ArrayList<Chat> mensagens = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();
            //String sql = "SELECT nome, estado FROM Chat WHERE estado = ?";
            String sql = "SELECT nome, tag, texto FROM CYP.chat WHERE comunidade  =? ";
            PreparedStatement consulta = c.prepareStatement(sql);
            //ATENÇÃO: DESCOMENTAR A LINHA ABAIXO PARA SELECIONAR SÓ QUEM TÁ COM ESTADO true
            consulta.setString(1, NomeComunidade);

            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                Chat atual = new Chat();

                atual.setNome(resultado.getString("nome"));
                atual.setTag(resultado.getInt("tag"));
                atual.setTexto(resultado.getString("texto"));

                mensagens.add(atual);

            }
            c.close();
        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao buscar as mensagens da comunidade: " + ex.getMessage());
        }

        return mensagens;
    }

}
