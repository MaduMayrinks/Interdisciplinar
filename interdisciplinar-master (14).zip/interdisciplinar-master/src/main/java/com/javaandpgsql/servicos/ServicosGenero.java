
package com.javaandpgsql.servicos;

import com.javaandpgsql.conexao.Conexao;
import com.javaandpgsql.model.Generos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 0068962
 */
public class ServicosGenero {
    
    public void AdicionarGene(String nome) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO CYP.generos (nome) VALUES (?)";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);

            // Executar a consulta para adicionar o novo gênero
            int linhasAfetadas = consulta.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Novo gênero adicionado com sucesso!");
            } else {
                System.out.println("Falha ao adicionar o gênero.");
            }
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicosGenero.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Generos ReturnGenero(String nome) {
        Generos retorno = new Generos();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT codigo, nome FROM CYP.generos WHERE nome = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);
            ResultSet resultado = consulta.executeQuery();
            c.close();
            if (resultado.next()) {
                retorno.setCodigo(resultado.getInt("codigo"));
                retorno.setNome(resultado.getString("nome"));
                return retorno;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosGenero.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        // Retorna null se não encontrar o e-mail no banco de dados.
    }
    
    public boolean ConsultarSeGeneroExiste(String nome) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT codigo, nome FROM CYP.generos WHERE lower(nome) = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome.toLowerCase());
            ResultSet resultado = consulta.executeQuery();
                            c.close();
            if (resultado.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosGenero.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        // Retorna null se não encontrar o e-mail no banco de dados.
    }
    
    public List<Generos> RetornaTodosGeneros() {
        List<Generos> retorno = new ArrayList<Generos>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT codigo, nome FROM CYP.generos ";
            PreparedStatement consulta = c.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery();

            while(resultado.next()) {
                Generos atual = new Generos();
                
                atual.setCodigo(resultado.getInt("codigo"));
                atual.setNome(resultado.getString("nome"));
                                
                retorno.add(atual);
            }
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicosGenero.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
        // Retorna null se não encontrar o e-mail no banco de dados.
    }
    
    
    public List<Generos> RetornaGenerosComFiltro(String nome) {
        List<Generos> retorno = new ArrayList<Generos>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql="";
            
            if(nome.trim().equalsIgnoreCase("")){
                sql = "SELECT codigo, nome FROM CYP.generos ";
            }else{
                sql = "SELECT codigo, nome FROM CYP.generos WHERE nome ilike '"+nome.trim()+"%'";
            }
            PreparedStatement consulta = c.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery();

            while(resultado.next()) {
                Generos atual = new Generos();
                
                atual.setCodigo(resultado.getInt("codigo"));
                atual.setNome(resultado.getString("nome"));
                                
                retorno.add(atual);
            }
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicosGenero.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
        // Retorna null se não encontrar o e-mail no banco de dados.
    }    
    
}
