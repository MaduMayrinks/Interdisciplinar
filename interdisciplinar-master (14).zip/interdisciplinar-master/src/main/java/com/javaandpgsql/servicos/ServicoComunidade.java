package com.javaandpgsql.servicos;

import com.javaandpgsql.conexao.Conexao;
import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServicoComunidade {

    public int gravarComunidade(Comunidade info) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO CYP.comunidade(imagem,descricao,nome,adm,idade,genero,tagusuario) "
                    + " VALUES (?,?,?,?,?,?,?)returning tag;";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, info.getImagem());
            insercao.setString(2, info.getDescricao());
            insercao.setString(3, info.getNome());
            insercao.setString(4, info.getNomedono());
            insercao.setInt(5, info.getRecomenda_idade());
            insercao.setString(6, info.getGenero());
            insercao.setInt(7, info.getTagUsuario());
            insercao.execute();
            ResultSet retorno = insercao.getGeneratedKeys();
            //insercao.executeUpdate();
            int tagInserida = 0;
            if (retorno.next()) {
                tagInserida = retorno.getInt("tag");
                info.setTag(tagInserida);
            }
            c.close();
            return tagInserida;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    public int ReturnTagComunidade(String nome) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT tag FROM CYP.comunidade WHERE nome = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int tag = resultado.getInt("tag");
                c.close();
                return tag;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public Comunidade RetornaComunidae(int tag) {
        Comunidade comunidade = new Comunidade();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT * FROM CYP.comunidade WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                // Preencha os detalhes da comunidade (substitua com os campos reais do seu banco de dados)
                String imagem = resultado.getString("imagem");
                String descricao = resultado.getString("descricao");
                int recomendaIdade = resultado.getInt("idade");
                String nome = resultado.getString("nome");
                String nomedono = resultado.getString("adm");
                String genero = resultado.getString("genero");
                int tagUsuario = resultado.getInt("tagUsuario");
                // Crie uma instância de Comunidade com os detalhes obtidos
                comunidade = new Comunidade(imagem, descricao, recomendaIdade, nome, nomedono, tag, genero, tagUsuario);

            }

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return comunidade;
    }

    public String RetornaNome(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT adm FROM CYP.comunidade WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String adm = resultado.getString("adm");
                c.close();
                return adm;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public int TagUsuarioComunidade(Usuarios dados, Comunidade info) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = " SELECT *  FROM CYP.comunidade JOIN CYP.usuario ON comunidade.tagusuario = usuario.tag  WHERE usuario.tag = ?;";
            PreparedStatement consulta = c.prepareStatement(sql);
            // Defina os parâmetros ou a condição de junção conforme necessário
            consulta.setInt(1, dados.getTag());

            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int tag = resultado.getInt("tag");
                c.close();
                return tag;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public List<Comunidade> pegarcomunidadesUsuarios(Usuarios info) {
        List<Comunidade> comunidadesusuario = new ArrayList<>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = " SELECT nome, descricao, tag, genero, idade, imagem  FROM CYP.comunidade WHERE tagusuario = ?;";
            PreparedStatement consulta = c.prepareStatement(sql);
            // Defina os parâmetros ou a condição de junção conforme necessário
            consulta.setInt(1, info.getTag());
            ResultSet resultado = consulta.executeQuery();
            while (resultado.next()) {
                Comunidade atual = new Comunidade();
                atual.setNome(resultado.getString("nome"));
                atual.setTag(resultado.getInt("tag"));
                atual.setDescricao(resultado.getString("descricao"));
                atual.setGenero(resultado.getString("genero"));
                atual.setImagem(resultado.getString("imagem"));
                atual.setRecomenda_idade(resultado.getInt("idade"));
                comunidadesusuario.add(atual);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
        return comunidadesusuario;
    }

    public List<Integer> pegarcomunidadesUsuariosTag(Comunidade info) {
        List<Integer> comunidadesusuario = new ArrayList<>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = " SELECT tag  FROM CYP.comunidade   WHERE tag = ?;";
            PreparedStatement consulta = c.prepareStatement(sql);
            // Defina os parâmetros ou a condição de junção conforme necessário
            consulta.setInt(1, info.getTag());
            ResultSet resultado = consulta.executeQuery();
            while (resultado.next()) {
                int tag = resultado.getInt("tag");

                comunidadesusuario.add(tag);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
        return comunidadesusuario;
    }

    // Método para obter todas as comunidades
    public List<Comunidade> obterTodasComunidades() {
        List<Comunidade> comunidades = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT * FROM CYP.comunidade";
            PreparedStatement consulta = c.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                // Preencha os detalhes da comunidade (substitua com os campos reais do seu banco de dados)
                String imagem = resultado.getString("imagem");
                String descricao = resultado.getString("descricao");
                int recomendaIdade = resultado.getInt("idade");
                String nome = resultado.getString("nome");
                String nomedono = resultado.getString("adm");
                String genero = resultado.getString("genero");
                int tag = resultado.getInt("tag");
                int tagUsuario = resultado.getInt("tagUsuario");
                // Crie uma instância de Comunidade com os detalhes obtidos
                Comunidade comunidade = new Comunidade(imagem, descricao, recomendaIdade, nome, nomedono, tag, genero, tagUsuario);
                comunidades.add(comunidade);
            }

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

        return comunidades;
    }

    public String tagComunidade(String nome) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT tag FROM CYP.comunidade WHERE nome = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String tagzinha = resultado.getString("tag");
                c.close();
                return tagzinha;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        //retorna tag da comunidade

    }

    public boolean UpdateDados(Comunidade dados) {
        try {
            Connection c = Conexao.obeterConexao();

            // A consulta SQL para atualização,  não deve ter um ResultSet
            String sql = "UPDATE CYP.comunidade SET imagem = ?, descricao = ?, nome = ?, idade = ?, genero = ? WHERE tag = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            // Configurando os parâmetros para a atualização
            atualizacao.setString(1, dados.getImagem());
            atualizacao.setString(2, dados.getDescricao());
            atualizacao.setString(3, dados.getNome());
            atualizacao.setInt(4, dados.getRecomenda_idade());
            atualizacao.setString(5, dados.getGenero());
            atualizacao.setInt(6, dados.getTag());

            // Executando a atualização
            int linhasAfetadas = atualizacao.executeUpdate();

            // Verificando se a atualização foi bem-sucedida
            if (linhasAfetadas > 0) {
                //se a atualização deu certo, ele retorna true
                return true;
            }

            // Fechando a conexão
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;

    }

    public ArrayList<Usuarios> USerONLista() {

        ArrayList<Usuarios> remetentes = new ArrayList<>();

        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nome, estado, tag FROM CYP.usuario WHERE estado  =? ";
            PreparedStatement consulta = c.prepareStatement(sql);

            consulta.setInt(1, 1);

            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                Usuarios atual = new Usuarios();

                atual.setNome(resultado.getString("nome"));
                ////ATENÇÃO: DESCOMENTAR A LINHA ABAIXO PARA SELECIONAR SÓ QUEM TÁ COM ESTADO true
                atual.setTag(resultado.getInt("tag"));
                atual.setEstado(resultado.getInt("estado"));

                remetentes.add(atual);

            }

            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
        }
        return remetentes;

    }

    public List<Comunidade> consultarPorOutroFiltroComOU(String digitado) {
        try {
            List<Comunidade> retorno = new ArrayList<Comunidade>();
            Connection c = Conexao.obeterConexao();

            String sql = "SELECT * FROM CYP.comunidade   ";

            if (!digitado.equalsIgnoreCase("")) {

                if (digitado != null && !digitado.equalsIgnoreCase("")) {
                    sql += " WHERE ";
                    sql += " nome ILIKE '" + digitado.trim() + "%'";
                }

            }
            Statement consulta = c.createStatement();
            ResultSet resultado = consulta.executeQuery(sql);
            while (resultado.next()) {
                Comunidade atual = new Comunidade();
                //String digitadousuario = resultado.getString("nome");
                //atual.
                atual.setNome(resultado.getString("nome"));
                atual.setTag(resultado.getInt("tag"));
                retorno.add(atual);
            }
            c.close();
            return retorno;
        } catch (SQLException ex) {
            Logger.getLogger(ServicoComunidade.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
