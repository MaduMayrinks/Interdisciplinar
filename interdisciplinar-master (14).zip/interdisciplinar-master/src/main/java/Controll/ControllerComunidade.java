package Controll;

import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import com.javaandpgsql.servicos.ServicoComunidade;
import java.util.ArrayList;
import java.util.List;

public class ControllerComunidade {

    ServicoComunidade Servico = new ServicoComunidade();

    public void CadastrarComunidade(Comunidade NovaComunidade) {
        Servico = new ServicoComunidade();
        Servico.gravarComunidade(NovaComunidade);
    }

    public int TagComunidade(String nome) {
        return Servico.ReturnTagComunidade(nome);
    }

    public String nomeUsuario(int tag) {
        return Servico.RetornaNome(tag);
    }

    public List<Comunidade> ComunidadeALL() {
        return Servico.obterTodasComunidades();

    }

    public boolean atualizandoComunide(Comunidade dados) {
        return Servico.UpdateDados(dados);
    }

    public Comunidade SelecionaComunidade(int tag) {
        return Servico.RetornaComunidae(tag);
    }

    public ArrayList<Usuarios> USerONLista() {
        return this.Servico.USerONLista();
    }

    public List<Comunidade> ConsultaFiltro(String Digitado) {
        return Servico.consultarPorOutroFiltroComOU(Digitado);
    }

    public List<Comunidade> PegarComunidadeUsuario(Usuarios dados) {
        return Servico.pegarcomunidadesUsuarios(dados);
    }
}
