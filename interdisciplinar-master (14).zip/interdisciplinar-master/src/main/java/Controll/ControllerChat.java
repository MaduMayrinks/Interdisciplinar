/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controll;

import com.javaandpgsql.model.Chat;
import com.javaandpgsql.model.Usuarios;
import com.javaandpgsql.servicos.ServicoChat;
import java.util.ArrayList;

/**
 *
 * @author 0068957
 */
public class ControllerChat {
    ServicoChat servico = new ServicoChat();
    public void Gravarchat (Chat dados){
        servico.GravarMSG(dados);
    }
    
    public ArrayList<Chat> Mensagens(String nomeComunidade){
        return this.servico.MensagensComunidade(nomeComunidade);
    }
}
