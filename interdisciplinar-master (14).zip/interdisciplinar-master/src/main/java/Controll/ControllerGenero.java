/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controll;

import com.javaandpgsql.model.Generos;
import com.javaandpgsql.servicos.ServicosGenero;
import java.util.List;

public class ControllerGenero {
    
    private ServicosGenero servicos; 
    
    public String consultaGenero(String nome) {
        servicos = new ServicosGenero();
        String gene = String.valueOf(servicos.ReturnGenero(nome));
        return gene;
    }

    public boolean ConsultarSeGeneroExiste(String nome) {
       servicos = new ServicosGenero();
        return servicos.ConsultarSeGeneroExiste(nome);
    }
    
    public boolean InserirGenero(String nome) {
       servicos = new ServicosGenero();
        servicos.AdicionarGene(nome);
        return true;
    }
    public List<Generos> RetornaTodosGeneros() {
        servicos=new ServicosGenero();
        return servicos.RetornaTodosGeneros();
    }
    
    public Generos consultaObjGenero(String nome) {
        servicos = new ServicosGenero();
        Generos gene = servicos.ReturnGenero(nome);
        return gene;
    }
    
    public List<Generos> RetornaGenerosComFiltro(String filtro) {
        servicos=new ServicosGenero();
        return servicos.RetornaGenerosComFiltro(filtro);
    }


}
