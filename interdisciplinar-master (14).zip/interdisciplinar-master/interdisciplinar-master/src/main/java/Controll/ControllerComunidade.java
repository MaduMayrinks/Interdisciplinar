

package Controll;

import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.servicos.ServicoComunidade;

public class ControllerComunidade {
    ServicoComunidade Servico;
    
    //GravandoComunidade no banco
    public void CadastrarComunidade(Comunidade NovaComunidade){
        Servico = new ServicoComunidade();
        Servico.gravarComunidade(NovaComunidade);
    }
    
    //RetornaTagdaComunidade
    public int TagComunidade(String nome){
        return Servico.ReturnTagComunidade(nome);
    }
    
    public String nomeUsuario(int tag){
        return Servico.RetornaNome(tag);
    }
}
