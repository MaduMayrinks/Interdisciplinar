package Controll;

import com.javaandpgsql.model.Usuarios;
import com.javaandpgsql.servicos.ServicosUsuarios;

public class ControllerUsuarios {

    ServicosUsuarios Servicos = new ServicosUsuarios();
    boolean Retorno = false;

    //gravando usuários no banco de dados.
    public void cadastrarUsuarios(Usuarios dados) {
        Servicos.gravarUsuario(dados);
        System.out.println("Ola");
    }

    //Verificando se o email do usuario já existe, utilizando os serviços do úsuario.
    public boolean verificaLogin(String email, String senha) {
        Servicos = new ServicosUsuarios();
        if (Servicos.verificaLoginUsuario(email, senha) != false) {
            Retorno = true; //existe
        }
        return Retorno; //retorna false
    }

    public boolean verificaEmail(String email) {
        Servicos = new ServicosUsuarios();
        if (Servicos.verificaEmail(email) == true){
            Retorno = true; //existe
        }
        return Retorno;
    }

    //função que retorna o nome a partir do email cadastrado...
    public String retornandoNome(int tag) {
        String nome = Servicos.RetornaNome(tag);
        return nome;
    }

    public String retornandoImagem(int tag) {
        String imagem = Servicos.RetornaImagem(tag);
        return imagem;
    }

    public int retornandoIdade(int tag) {
        int idade = Servicos.RetornaIdade(tag);
        return idade;
    }

    public String retornandoNomeU(int tag) {
        String nomeU = Servicos.RetornaNomeUsuario(tag);
        return nomeU;
    }

    public String retornandoGenero(int tag) {
        String genero = Servicos.RetornaGenero(tag);
        return genero;
    }

    public String retornandoSenha(int tag) {
        String senhaUsuario = Servicos.Retornasenha(tag);
        return senhaUsuario;
    }

    public String retornandoEmail(int tag) {
        String email = Servicos.retornaEmail(tag);
        return email;
    }

    public int retornandoTag(String email, String senha) {
        int tag = Servicos.retornaTag(email, senha);
        return tag;
    }
    
    public boolean atualizandoConta(Usuarios dados){
        Retorno = Servicos.UpdateDados(dados);
        return Retorno;
    }
    
}
