package com.javaandpgsql.telas;

import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class PrincipalRainha extends javax.swing.JFrame {

    private MinhaConta conta;
    private Usuarios dadosAtuais;
    private Comunidade repassandoDados;
    private CadastroComunidade chamarcomunidade;

    public PrincipalRainha() {
        initComponents();
        baixarImagem();
        this.setLocationRelativeTo(null);
        cantinhodaComunidade();
        //ImgMinhaconta();
    }

    public PrincipalRainha(Usuarios enviaDados) {
        initComponents();
        baixarImagem();
        //ImgMinhaconta();
        dadosAtuais = enviaDados;

        //Enviando dados do usuario para Minhaconta
        conta = new MinhaConta(enviaDados);
        this.setLocationRelativeTo(null);
        abreopcoesfundo.setVisible(false);

        baixarImagem(enviaDados);
        cantinhodaComunidade();
    }

    public PrincipalRainha(Comunidade pegandoDadosC) {
        initComponents();
        baixarImagem();
        //ImgMinhaconta();
        repassandoDados = pegandoDadosC;
        this.setLocationRelativeTo(null);
        cantinhodaComunidade();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        abreopcoesfundo = new javax.swing.JPanel();
        criarcomunidade = new javax.swing.JLabel();
        comunidadesUsuarios = new javax.swing.JLabel();
        cantinhodacomunidade = new javax.swing.JPanel();
        trespontos = new javax.swing.JLabel();
        fotinha = new javax.swing.JLabel();
        MinhaContaLabel = new javax.swing.JLabel();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        abreopcoesfundo.setBackground(new java.awt.Color(255, 244, 204));

        criarcomunidade.setForeground(new java.awt.Color(51, 51, 51));
        criarcomunidade.setText("Criar comunidade");
        criarcomunidade.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                criarcomunidadeMousePressed(evt);
            }
        });

        comunidadesUsuarios.setForeground(new java.awt.Color(51, 51, 51));
        comunidadesUsuarios.setText("Minhas Comunidades");

        javax.swing.GroupLayout abreopcoesfundoLayout = new javax.swing.GroupLayout(abreopcoesfundo);
        abreopcoesfundo.setLayout(abreopcoesfundoLayout);
        abreopcoesfundoLayout.setHorizontalGroup(
            abreopcoesfundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(abreopcoesfundoLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(abreopcoesfundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(comunidadesUsuarios)
                    .addGroup(abreopcoesfundoLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(criarcomunidade)))
                .addGap(26, 26, 26))
        );
        abreopcoesfundoLayout.setVerticalGroup(
            abreopcoesfundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(abreopcoesfundoLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(criarcomunidade)
                .addGap(18, 18, 18)
                .addComponent(comunidadesUsuarios)
                .addContainerGap())
        );

        jPanel1.add(abreopcoesfundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1340, 360, 140, 170));

        cantinhodacomunidade.setBackground(new java.awt.Color(98, 62, 171));

        javax.swing.GroupLayout cantinhodacomunidadeLayout = new javax.swing.GroupLayout(cantinhodacomunidade);
        cantinhodacomunidade.setLayout(cantinhodacomunidadeLayout);
        cantinhodacomunidadeLayout.setHorizontalGroup(
            cantinhodacomunidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 990, Short.MAX_VALUE)
        );
        cantinhodacomunidadeLayout.setVerticalGroup(
            cantinhodacomunidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        jPanel1.add(cantinhodacomunidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 220, 990, 500));

        trespontos.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        trespontos.setText("...");
        trespontos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                trespontosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                trespontosMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                trespontosMousePressed(evt);
            }
        });
        jPanel1.add(trespontos, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 270, 60, 60));

        fotinha.setText(".");
        fotinha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                fotinhaMousePressed(evt);
            }
        });
        jPanel1.add(fotinha, new org.netbeans.lib.awtextra.AbsoluteConstraints(1430, 10, 60, 60));

        MinhaContaLabel.setForeground(new java.awt.Color(51, 51, 255));
        MinhaContaLabel.setText("Minha conta");
        MinhaContaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MinhaContaLabelMousePressed(evt);
            }
        });
        jPanel1.add(MinhaContaLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, 230, 70));
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1524, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 787, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 private void baixarImagem() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\principaalrainha.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1532, 805, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fotofundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\labelminhacontaoriginal.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(321, 91, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                MinhaContaLabel.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }

    }

    private void cantinhodaComunidade() {
        repassandoDados = new Comunidade();
        String enviaTag = String.valueOf(repassandoDados.getTag());
        String enviaNome = repassandoDados.getNome();
        cantinhodacomunidade.setLayout(new GridLayout(2, 4, 20, 40));
        cantinhodacomunidade.add(new ModelComunidade(enviaTag, enviaNome));
        cantinhodacomunidade.add(new ModelComunidade("", ""));
        cantinhodacomunidade.add(new ModelComunidade("", ""));
        cantinhodacomunidade.add(new ModelComunidade("", ""));
        cantinhodacomunidade.add(new ModelComunidade("", ""));
        cantinhodacomunidade.add(new ModelComunidade("", ""));
        cantinhodacomunidade.add(new ModelComunidade("", ""));
        cantinhodacomunidade.add(new ModelComunidade("", ""));

    }

    private void baixarImagem(Usuarios dados) {

        URL novaURl;
        try {
            novaURl = new URL(dados.getImagem());
            BufferedImage imagemmmm = ImageIO.read(novaURl);
            ImageIcon imgI = new ImageIcon(imagemmmm);
            imgI.setImage(imgI.getImage().getScaledInstance(45, 45, 100));
            fotinha.setIcon(imgI);
        } catch (MalformedURLException ex) {
            Logger.getLogger(PrincipalRainha.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(PrincipalRainha.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    private void MinhaContaLabelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinhaContaLabelMousePressed
        conta.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        conta.setVisible(true);
        dispose();
    }//GEN-LAST:event_MinhaContaLabelMousePressed

    private void trespontosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trespontosMouseEntered


    }//GEN-LAST:event_trespontosMouseEntered

    private void criarcomunidadeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_criarcomunidadeMousePressed
        chamarcomunidade = new CadastroComunidade(dadosAtuais);
        chamarcomunidade.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        chamarcomunidade.setVisible(true);
        dispose();

    }//GEN-LAST:event_criarcomunidadeMousePressed

    private void trespontosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trespontosMouseExited

    }//GEN-LAST:event_trespontosMouseExited

    private void trespontosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_trespontosMousePressed
        abreopcoesfundo.setVisible(true);

    }//GEN-LAST:event_trespontosMousePressed

    private void fotinhaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fotinhaMousePressed
        // TODO add your handling code here:
        conta.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        conta.setVisible(true);
        dispose();
    }//GEN-LAST:event_fotinhaMousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrincipalRainha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrincipalRainha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrincipalRainha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrincipalRainha.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Usuarios enviaDados = null;
                new PrincipalRainha(enviaDados).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel MinhaContaLabel;
    private javax.swing.JPanel abreopcoesfundo;
    private javax.swing.JPanel cantinhodacomunidade;
    private javax.swing.JLabel comunidadesUsuarios;
    private javax.swing.JLabel criarcomunidade;
    private javax.swing.JLabel fotinha;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel trespontos;
    // End of variables declaration//GEN-END:variables
}
