package com.javaandpgsql.servicos;

import com.javaandpgsql.model.Usuarios;
import com.javaandpgsql.conexao.Conexao;
import com.javaandpgsql.model.Comunidade;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServicosUsuarios {

    public int gravarUsuario(Usuarios dados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO CYP.usuario(nome,email,senha,genero,idade,nomeUsuario,imagem) "
                    + " VALUES (?,?,?,?,?,?,?) returning tag ;";
            PreparedStatement insercao = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            insercao.setString(1, dados.getNome());
            insercao.setString(2, dados.getEmail());
            insercao.setString(3, dados.getSenha());
            insercao.setString(4, dados.getGenero());
            insercao.setInt(5, dados.getIdade());
            insercao.setString(6, dados.getNomeUsuario());
            insercao.setString(7, dados.getImagem());
            System.out.println(dados.getEmail());
            System.out.println(dados.getSenha());
            insercao.execute();
            ResultSet retorno = insercao.getGeneratedKeys();
            //insercao.executeUpdate();
            int tagInserida = 0;
            if (retorno.next()) {
                tagInserida = retorno.getInt("tag");
                dados.setTag(tagInserida);
            }
            c.close();
            return tagInserida;
        } catch (SQLException ex) {
            System.out.println("parou");
            ex.printStackTrace();
            return 0;
        }
    }

    public boolean verificaLoginUsuario(String email, String senha) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM CYP.usuario WHERE email = ? AND senha = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, email);
            consulta.setString(2, senha);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);
                c.close();
                return count > 0; // Retorna true se o cliente com o email especificado já foi cadastrado.
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false;
    }

    public boolean verificaEmail(String email) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT COUNT(*) FROM CYP.usuario WHERE email = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, email);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int count = resultado.getInt(1);
                c.close();
                return count > 0; // Retorna true se o cliente com o email especificado já foi cadastrado.
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return false;
    }

    public void gravarImagem(Usuarios dados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO CYP.usuario(imagem) "
                    + " VALUES (?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, dados.getImagem());

            ResultSet retorno = insercao.executeQuery();
            insercao.executeUpdate(); // Use executeUpdate para operações de INSERT, UPDATE, DELETE
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //RETORNOS
    public List<Usuarios> retornarDados(Usuarios dados) {
        List<Usuarios> usuarios = new ArrayList<>();
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nome, email, senha, genero, idade, nomeUsuario, imagem FROM CYP.usuario WHERE tag = ?";

            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setInt(1, dados.getTag());
            ResultSet retorno = insercao.executeQuery();
            while (retorno.next()) {
                dados = new Usuarios();
                dados.setNome(retorno.getString("nome"));
                dados.setEmail(retorno.getString("email"));
                dados.setSenha(retorno.getString("senha"));
                dados.setGenero(retorno.getString("genero"));
                dados.setIdade(retorno.getInt("idade"));
                dados.setNomeUsuario(retorno.getString("nomeUsuario"));
                dados.setImagem(retorno.getString("imagem"));

                usuarios.add(dados);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return usuarios;
    }

    
    
    public boolean UpdateDados (Usuarios dados) {
        try {
            Connection c = Conexao.obeterConexao();

            // A consulta SQL para atualização não deve ter um ResultSet
            String sql = "UPDATE CYP.usuario SET nome = ?, senha = ?, nomeUsuario = ?, imagem = ?, email = ? WHERE tag = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            // Configurando os parâmetros para a atualização
            atualizacao.setString(1, dados.getNome());
            atualizacao.setString(2, dados.getSenha());
            atualizacao.setString(3, dados.getNomeUsuario());
            atualizacao.setString(4, dados.getImagem());
            atualizacao.setString(5, dados.getEmail());
            atualizacao.setInt(6, dados.getTag());

            // Executando a atualização
            int linhasAfetadas = atualizacao.executeUpdate();

            // Verificando se a atualização foi bem-sucedida
            if (linhasAfetadas > 0) {
                //se a atualização deu certo, ele retorna true
             return true;
            }

            // Fechando a conexão
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    
    }

    public String RetornaNome(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nome FROM CYP.usuario WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String nome = resultado.getString("nome");
                c.close();
                return nome;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
        // Retorna null se não encontrar o e-mail no banco de dados.
    }

    public String RetornaImagem(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT imagem FROM CYP.usuario WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String imagem = resultado.getString("imagem");
                c.close();
                return imagem;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
        // Retorna null se não encontrar o e-mail no banco de dados.
    }

    public int RetornaIdade(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT idade FROM CYP.usuario WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int idade = resultado.getInt("idade");
                c.close();
                return idade;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return 0;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public String RetornaNomeUsuario(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT nomeusuario FROM CYP.usuario WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String nomeUsu = resultado.getString("nomeusuario");
                c.close();
                return nomeUsu;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public String RetornaGenero(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT genero FROM CYP.usuario WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String genero = resultado.getString("genero");
                c.close();
                return genero;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public String Retornasenha(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT senha FROM CYP.usuario WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String senhaUsuario = resultado.getString("senha");
                c.close();
                return senhaUsuario;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public String retornaEmail(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT email FROM CYP.usuario WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String email = resultado.getString("email");
                c.close();
                return email;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public int retornaTag(String email, String senha) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT tag FROM CYP.usuario WHERE email = ? AND senha=?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, email);
            consulta.setString(2, senha);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int tag = resultado.getInt("tag");
                c.close();
                return tag;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return 0;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public String RetornaComunidade(String nome) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT tag FROM CYP.comunidade WHERE nome = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String tagzinha = resultado.getString("tag");
                c.close();
                return tagzinha;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public void atualizarCadastroUsuario(int tag, Usuarios novosDados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "UPDATE CYP.usuario SET nome = ?, senha = ?, genero = ?, idade = ?, nomeUsuario = ?, imagem = ?, email = ? WHERE tag = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            atualizacao.setString(1, novosDados.getNome());
            atualizacao.setString(2, novosDados.getSenha());
            atualizacao.setString(3, novosDados.getGenero());
            atualizacao.setInt(4, novosDados.getIdade());
            atualizacao.setString(5, novosDados.getNomeUsuario());
            atualizacao.setString(6, novosDados.getImagem());
            atualizacao.setString(7, novosDados.getEmail());

            int linhasAfetadas = atualizacao.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro do usuário atualizado com sucesso!");
            } else {
                System.out.println("Usuário não encontrado ou nenhum dado foi alterado.");
            }

            c.close();

        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void atualizarCadastroNome(String tag, Usuarios novosDados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "UPDATE CYP.usuario SET nome = ? WHERE email = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            atualizacao.setString(1, novosDados.getNome());

            int linhasAfetadas = atualizacao.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro do usuário atualizado com sucesso!");
            } else {
                System.out.println("Usuário não encontrado ou nenhum dado foi alterado.");
            }

            c.close();

        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void atualizarCadastroNick(String tag, Usuarios novosDados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "UPDATE CYP.usuario SET nomeUsuario = ? WHERE tag = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            atualizacao.setString(1, novosDados.getNomeUsuario());

            int linhasAfetadas = atualizacao.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro do usuário atualizado com sucesso!");
            } else {
                System.out.println("Usuário não encontrado ou nenhum dado foi alterado.");
            }

            c.close();

        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void atualizarCadastroEmail(String email, Usuarios novosDados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "UPDATE CYP.usuario SET email = ? WHERE email = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            atualizacao.setString(1, novosDados.getEmail());

            int linhasAfetadas = atualizacao.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro do usuário atualizado com sucesso!");
            } else {
                System.out.println("Usuário não encontrado ou nenhum dado foi alterado.");
            }

            c.close();

        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void atualizarCadastroSenha(String email, Usuarios novosDados) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "UPDATE CYP.usuario SET senha = ? WHERE email = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            atualizacao.setString(1, novosDados.getSenha());

            int linhasAfetadas = atualizacao.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Cadastro do usuário atualizado com sucesso!");
            } else {
                System.out.println("Usuário não encontrado ou nenhum dado foi alterado.");
            }

            c.close();

        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

}
