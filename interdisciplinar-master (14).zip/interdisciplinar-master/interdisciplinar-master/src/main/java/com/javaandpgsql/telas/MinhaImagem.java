package com.javaandpgsql.telas;

import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Usuarios;
import com.javaandpgsql.servicos.ServicosUsuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class MinhaImagem extends javax.swing.JFrame {

    MinhaConta chamaConta;
    Usuarios dadosRecebidos;
    ControllerUsuarios Acessa;

    public MinhaImagem() {
        initComponents();
        baixaImagemfundoLUA();
        this.setLocationRelativeTo(null);
    }

    public MinhaImagem(Usuarios Recebedados) {
        initComponents();
        dadosRecebidos = Recebedados;
        baixaImagemfundoLUA();
        this.setLocationRelativeTo(null);
    }

    public void exibirImagem(BufferedImage imagemUsuario) {
        if (imagemUsuario != null) {
            //Crie um ImageIcon a partir da imagem e defina no JLabel
            ImageIcon icon = new ImageIcon(imagemUsuario);
        }
    }

    private void baixaImagemfundoLUA() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\imagemUsuarioEditar.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(524, 462, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                jLabel1.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\SALVAR.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(210, 210, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                SalvarLbl.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }
        
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\voltar.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(210, 210, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                voltarLbl.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        voltarLbl = new javax.swing.JLabel();
        Urltxt = new javax.swing.JTextField();
        SalvarLbl = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        voltarLbl.setForeground(new java.awt.Color(102, 204, 255));
        voltarLbl.setText("Voltar");
        voltarLbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                voltarLblMousePressed(evt);
            }
        });
        jPanel1.add(voltarLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 390, 190, 40));

        Urltxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UrltxtActionPerformed(evt);
            }
        });
        jPanel1.add(Urltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 390, 30));

        SalvarLbl.setText("salvar");
        jPanel1.add(SalvarLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 310, 190, 60));

        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel1MousePressed(evt);
            }
        });
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 470));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UrltxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UrltxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UrltxtActionPerformed

    private void voltarLblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_voltarLblMousePressed

        //voltando para tela MinhaConta e reenviando os dados do usuario(Atualizados ou não) 
        MinhaConta redirecionar = new MinhaConta(dadosRecebidos);
        redirecionar.setUrlImagem(this.Urltxt.getText());
        redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_voltarLblMousePressed

    private void jLabel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MousePressed
        // TODO add your handling code here:
        if (!Urltxt.getText().isEmpty()) {

            dadosRecebidos.setImagem(Urltxt.getText());
            Acessa.atualizandoConta(dadosRecebidos);

            if (this.chamaConta != null) {
                this.chamaConta.setUrlImagem(this.Urltxt.getText());
            }
            MinhaConta redirecionar = new MinhaConta(dadosRecebidos);
            redirecionar.setUrlImagem(this.Urltxt.getText());
            redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            redirecionar.setVisible(true);
            dispose();

        } else {
            if (this.chamaConta != null) {
                this.chamaConta.setUrlImagem(this.Urltxt.getText());
            }
            MinhaConta redirecionar = new MinhaConta(dadosRecebidos);
            redirecionar.setUrlImagem(this.Urltxt.getText());
            redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            redirecionar.setVisible(true);
            dispose();

        }

    }//GEN-LAST:event_jLabel1MousePressed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MinhaImagem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel SalvarLbl;
    private javax.swing.JTextField Urltxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel voltarLbl;
    // End of variables declaration//GEN-END:variables
}
