package com.javaandpgsql.telas;

import Controll.ControllerUsuarios;
import com.javaandpgsql.model.Usuarios;
import com.javaandpgsql.servicos.ServicosUsuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class CadastroUsuario extends javax.swing.JFrame {

    public CadastroUsuario() {
        initComponents();
        baixaImagemfundoLUA();

        setTitle("CYP");

        labelErro.setVisible(false);
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtSenha = new javax.swing.JPasswordField();
        txtNome = new javax.swing.JTextField();
        txtNomeUsuario = new javax.swing.JTextField();
        txtIdade = new javax.swing.JTextField();
        txtGenero = new javax.swing.JTextField();
        labelErro = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cadastrarBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        labelImagemFundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro de Alunos");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(78, 43, 182));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(253, 252, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("🛈");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 270, 20, 40));
        jPanel2.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 120, 260, -1));
        jPanel2.add(txtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 160, 260, -1));
        jPanel2.add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 200, 260, -1));
        jPanel2.add(txtNomeUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 240, 160, -1));
        jPanel2.add(txtIdade, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 280, 260, -1));
        jPanel2.add(txtGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 320, 240, -1));

        labelErro.setForeground(new java.awt.Color(255, 63, 63));
        labelErro.setText("Erro! Email em uso...");
        jPanel2.add(labelErro, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 100, 120, -1));

        jLabel4.setForeground(new java.awt.Color(153, 102, 255));
        jLabel4.setText("Login");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel4MousePressed(evt);
            }
        });
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 450, -1, -1));

        cadastrarBtn.setBackground(new java.awt.Color(51, 51, 51));
        cadastrarBtn.setFont(new java.awt.Font("ISOCPEUR", 0, 24)); // NOI18N
        cadastrarBtn.setForeground(new java.awt.Color(204, 204, 255));
        cadastrarBtn.setText("Cadastrar!");
        cadastrarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarBtnActionPerformed(evt);
            }
        });
        jPanel2.add(cadastrarBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 390, 143, 42));

        jLabel3.setText("Já tem uma conta?");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 450, -1, -1));
        jPanel2.add(labelImagemFundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, -1, 510));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 880, 490));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1209, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 718, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 private void baixaImagemfundoLUA() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\telacadastro.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(880, 490, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                labelImagemFundo.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }
    }
    private void cadastrarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarBtnActionPerformed
        // TODO add your handling code here:

        if (txtEmail.getText().isEmpty() || txtSenha.getText().isEmpty()
                || txtGenero.getText().isEmpty() || txtIdade.getText().isEmpty()
                || txtNome.getText().isEmpty() || txtNomeUsuario.getText().isEmpty()
                || txtSenha.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Preencha todos os componentes!", "Erro de inserção", JOptionPane.ERROR_MESSAGE);
        } else {

            Random gerador = new Random();
            Usuarios dadosUsuario = new Usuarios();
            dadosUsuario.setNome(txtNome.getText());

            ControllerUsuarios controlando = new ControllerUsuarios();

            //Verificando se o email do usuario já existe, utiliando o controler
            if (controlando.verificaEmail(txtEmail.getText()) == false) { //se for false é porque não existe...

                //Mandando os dados do usuario para o servico usuarios. Para que ele possa executar o gravar
                int idade = (Integer.parseInt(txtIdade.getText()));
                String nome = txtNome.getText();
                String email = (txtEmail.getText());

                String senha = (new String(txtSenha.getPassword()));
                String genero = (txtGenero.getText());
                String nomeUsuario = (txtNomeUsuario.getText());
                int algo = gerador.nextInt(1000, 9000);
                int codigo = algo;
                //imagem básica... (usuario)
                
            String caminho = System.getProperty("user.dir");
    
            File arquivoVerificacaoEmail = new File(caminho+"Desktop\\verificacaoemailcadastro.txt");
            try {
           arquivoVerificacaoEmail.createNewFile();
	    FileWriter escrita = new FileWriter(arquivoVerificacaoEmail, true);
            BufferedWriter bufEscrita = new BufferedWriter(escrita);
            String TranformaGerador=String.valueOf(algo);
            bufEscrita.write("Insira seu código de Verificação: " + "\n");
            bufEscrita.write(TranformaGerador +"\n");
            //if( infoverificacao.getText()==TranformaGerador){
            bufEscrita.flush();
            bufEscrita.close();
            //} else{
            //tela de erro    
                
           // }
	} catch (IOException e) {
		e.printStackTrace();	
	}
             
            
        
                
                String imagem = ("https://i.pinimg.com/originals/f5/98/b4/f598b4de6092c71b96a3fd12cf1ecb43.jpg");
                   int tag = controlando.retornandoTag(email, senha);
                dadosUsuario = new Usuarios(idade, nome, email, senha, genero, nomeUsuario, codigo, imagem, tag);
                //Chamando o gravar usuarios no banco
                controlando.cadastrarUsuarios(dadosUsuario);

                //tag do usuario
             

                //Repassando o usuario para o construtor, para manuseiarmos esses dados no código.
               

                //Chamando a principal rainha( que é a tela das comunidades e etc) para redirecionar a tela
                //E passando os dados do usuario para armazena los em minha conta
                PrincipalRainha redirecionar = new PrincipalRainha(dadosUsuario);
                redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                redirecionar.setVisible(true);
                dispose();

            } else {
                labelErro.setVisible(true);

            }
        }
    }//GEN-LAST:event_cadastrarBtnActionPerformed

    private void jLabel4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MousePressed
        // TODO add your handling code here:
        LoginUsuario redirecionar = new LoginUsuario();
        redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel4MousePressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastrarBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel labelErro;
    private javax.swing.JLabel labelImagemFundo;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtGenero;
    private javax.swing.JTextField txtIdade;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtNomeUsuario;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
