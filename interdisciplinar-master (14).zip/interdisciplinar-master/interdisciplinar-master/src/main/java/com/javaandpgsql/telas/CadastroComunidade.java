package com.javaandpgsql.telas;

import Controll.ControllerComunidade;
import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import com.javaandpgsql.servicos.ServicosUsuarios;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class CadastroComunidade extends javax.swing.JFrame {

    private String urlImagem;

    private Comunidade dadosComunidade=new Comunidade();
    private Usuarios repassanome;
    private ImagemComunidade repassaimagem;

    public CadastroComunidade(Usuarios nome) {
        initComponents();
        BaixarImagemCompts();
        repassanome = nome;
        this.setLocationRelativeTo(null);

        labelErroNome.setVisible(false);
        labelErroGene.setVisible(false);

    }

    public CadastroComunidade(Comunidade recebeurl) {
        initComponents();
        this.setLocationRelativeTo(null);
        BaixarImagemCompts();
        
        urlImagem = recebeurl.getImagem();
        baixaImagem();

        dadosComunidade.setImagem(recebeurl.getImagem());

    }

    private void voltarparacomunidade() {
        if(nometxt.getText().isBlank()&& generotxt.getText().isBlank()){
         labelErroNome.setVisible(true);
         labelErroGene.setVisible(true);
        }else{
        
        repassaimagem = new ImagemComunidade(dadosComunidade);
        repassaimagem.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        repassaimagem.setVisible(true);
        dispose();
        }
        if(!nometxt.getText().isBlank()&& generotxt.getText().isBlank()){
          
        
        repassaimagem = new ImagemComunidade(dadosComunidade);
        repassaimagem.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        repassaimagem.setVisible(true);
        dispose();
        }
        
        if(nometxt.getText().isBlank()){
           labelErroNome.setVisible(true);  
        }
       
         if(generotxt.getText().isBlank()){
         labelErroGene.setVisible(true);
         }
        
        
         
    }

    private CadastroComunidade() {
        initComponents();
        this.setLocationRelativeTo(null);
        labelErroNome.setVisible(false);
        labelErroGene.setVisible(false);
        baixaImagem();
        BaixarImagemCompts();
        nometxt.setText(dadosComunidade.getNome());
        descricaotxt.setText(dadosComunidade.getDescricao());
        recomendacaoidadetxt.setText(String.valueOf(dadosComunidade.getRecomenda_idade()));

    }

    public void baixaImagem() {

        URL novaURl;
        File arq;

        System.out.println(urlImagem);
        try {

            //novaURl = new URL(urlImagem);
            if (urlImagem.startsWith("https") || urlImagem.startsWith("http")) {
                novaURl = new URL(urlImagem);
                BufferedImage imagemmmm = ImageIO.read(novaURl);
                ImageIcon imgI = new ImageIcon(imagemmmm);
                imgI.setImage(imgI.getImage().getScaledInstance(150, 210, 100));
                fotolabel.setIcon(imgI);

            } else {
                arq = new File(urlImagem);
                BufferedImage imagemmmm = ImageIO.read(arq);
                ImageIcon imgI = new ImageIcon(imagemmmm);
                imgI.setImage(imgI.getImage().getScaledInstance(150, 210, 100));
                fotolabel.setIcon(imgI);

            }
        } catch (MalformedURLException ex) {
            ex.printStackTrace();

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void BaixarImagemCompts() {

        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\CriarCOMUNIDADEFUNDO.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(1024, 576, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                fundoimagem.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }

        //Baixar imagem de genero
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\adicionargenero.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(300, 169, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                Adicionargenero.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }

        //Baixar imagem voltar
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\voltar (1).png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(300, 169, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                voltar.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }

        //botão editar
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\editar.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(210, 210, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                editarLbl.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }

        //botao salvar
        try {
            String caminho = System.getProperty("user.dir");
            File fileImagem = new File(""
                    + caminho + "\\src\\main\\java\\com\\javaandpgsql\\imagem\\SALVAR.png"
                    + "");
            if (fileImagem != null) {
                BufferedImage imagem = ImageIO.read(fileImagem);

                // Cria um ImageIcon e redimensiona a imagem
                ImageIcon imgIcon = new ImageIcon(imagem);
                imgIcon.setImage(imgIcon.getImage().getScaledInstance(310, 310, Image.SCALE_SMOOTH));

                // Define o ícone para o JLabel
                salvarlbl.setIcon(imgIcon);
            } else {
                System.err.println("Imagem não encontrada no diretório src.");
            }

        } catch (IOException ex) {
            Logger.getLogger(MinhaConta.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("errei:  " + ex.getMessage());
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        labelErroNome = new javax.swing.JLabel();
        labelErroGene = new javax.swing.JLabel();
        nometxt = new javax.swing.JTextField();
        descricaoarea = new javax.swing.JScrollPane();
        descricaotxt = new javax.swing.JTextArea();
        generotxt = new javax.swing.JTextField();
        recomendacaoidadetxt = new javax.swing.JTextField();
        Tag = new javax.swing.JLabel();
        salvarlbl = new javax.swing.JLabel();
        Adicionargenero = new javax.swing.JLabel();
        voltar = new javax.swing.JLabel();
        editarLbl = new javax.swing.JLabel();
        fotolabel = new javax.swing.JLabel();
        fundoimagem = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelErroNome.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelErroNome.setForeground(new java.awt.Color(245, 20, 20));
        labelErroNome.setText("Insira o nome da comunidade!");
        jPanel1.add(labelErroNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 70, -1, -1));

        labelErroGene.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelErroGene.setForeground(new java.awt.Color(245, 20, 20));
        labelErroGene.setText("Insira o gênero!");
        jPanel1.add(labelErroGene, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 400, -1, -1));

        nometxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nometxtActionPerformed(evt);
            }
        });
        jPanel1.add(nometxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 40, 290, -1));

        descricaotxt.setColumns(20);
        descricaotxt.setRows(5);
        descricaoarea.setViewportView(descricaotxt);

        jPanel1.add(descricaoarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 150, 380, 180));
        jPanel1.add(generotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 370, 260, -1));
        jPanel1.add(recomendacaoidadetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 100, 80, -1));

        Tag.setText("#");
        jPanel1.add(Tag, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, 40, -1));

        salvarlbl.setIcon(new javax.swing.ImageIcon("C:\\Users\\0068962\\Downloads\\interdisciplinar-master (1)\\interdisciplinar-master\\src\\main\\java\\com\\javaandpgsql\\imagem\\SALVAR.png")); // NOI18N
        salvarlbl.setText("salvar");
        salvarlbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                salvarlblMousePressed(evt);
            }
        });
        jPanel1.add(salvarlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 480, 240, 70));

        Adicionargenero.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                AdicionargeneroMousePressed(evt);
            }
        });
        jPanel1.add(Adicionargenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 370, 290, 120));

        voltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                voltarMousePressed(evt);
            }
        });
        jPanel1.add(voltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(-100, 490, 190, 80));

        editarLbl.setText("Editar");
        editarLbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                editarLblMousePressed(evt);
            }
        });
        jPanel1.add(editarLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 230, 100));

        fotolabel.setText("foto");
        jPanel1.add(fotolabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 150, 210));
        jPanel1.add(fundoimagem, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1018, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void salvarlblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvarlblMousePressed

        //se ele inserir nada...
        if (nometxt.getText().isBlank() || descricaotxt.getText().isBlank()) {
            labelErroNome.setVisible(true);
            labelErroGene.setVisible(true);
        } else {

            ControllerComunidade gravar = new ControllerComunidade();

            String imagem = urlImagem;
            String descri = descricaotxt.getText();
            int recomendaIdade = Integer.parseInt(recomendacaoidadetxt.getText());
            String nome = nometxt.getText();
            String nomeAdm = repassanome.getNomeUsuario();
            String genero = generotxt.getText();

            dadosComunidade = new Comunidade(imagem, descri, recomendaIdade, nome, nomeAdm, 0, genero,repassanome.getTag());

            //Gravando a comunidade no BD
            gravar.CadastrarComunidade(dadosComunidade);
        }

        PrincipalRainha redirecionar = new PrincipalRainha(dadosComunidade);
        redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_salvarlblMousePressed

    private void voltarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_voltarMousePressed
        PrincipalRainha redirecionar = new PrincipalRainha();
        redirecionar.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_voltarMousePressed

    private void AdicionargeneroMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AdicionargeneroMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_AdicionargeneroMousePressed

    private void nometxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nometxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nometxtActionPerformed

    private void editarLblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarLblMousePressed
       //ELE SÓ APERTA O BOTÃO DE EDITAR SE ELE TIVER PREENCHIDO 
        voltarparacomunidade();
    }//GEN-LAST:event_editarLblMousePressed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroComunidade().setVisible(true);
            }
        });
    }

    public String getUrlImagem() {
        return urlImagem;
    }

    public void setUrlImagem(String urlImagem) {
        this.urlImagem = urlImagem;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Adicionargenero;
    private javax.swing.JLabel Tag;
    private javax.swing.JScrollPane descricaoarea;
    private javax.swing.JTextArea descricaotxt;
    private javax.swing.JLabel editarLbl;
    private javax.swing.JLabel fotolabel;
    private javax.swing.JLabel fundoimagem;
    private javax.swing.JTextField generotxt;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelErroGene;
    private javax.swing.JLabel labelErroNome;
    private javax.swing.JTextField nometxt;
    private javax.swing.JTextField recomendacaoidadetxt;
    private javax.swing.JLabel salvarlbl;
    private javax.swing.JLabel voltar;
    // End of variables declaration//GEN-END:variables
}
