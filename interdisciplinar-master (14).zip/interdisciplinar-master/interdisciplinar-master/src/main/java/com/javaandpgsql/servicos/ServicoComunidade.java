package com.javaandpgsql.servicos;

import com.javaandpgsql.conexao.Conexao;
import com.javaandpgsql.model.Comunidade;
import com.javaandpgsql.model.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServicoComunidade {

    public void gravarComunidade(Comunidade info) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "INSERT INTO CYP.comunidade(imagem,descricao,nome,adm,idade,genero) "
                    + " VALUES (?,?,?,?,?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, info.getImagem());
            insercao.setString(2, info.getDescricao());
            insercao.setString(3, info.getNome());
            insercao.setString(4, info.getNomedono());
            insercao.setInt(5, info.getRecomenda_idade());
            insercao.setString(6, info.getGenero());
            //ResultSet retorno = insercao.executeQuery();
            insercao.executeUpdate(); // Use executeUpdate para operações de INSERT, UPDATE, DELETE
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public int ReturnTagComunidade(String nome) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT tag FROM CYP.comunidade WHERE nome = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                int tag = resultado.getInt("tag");
                c.close();
                return tag;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return 0;
// Retorna null se não encontrar o e-mail no banco de dados.
    }

    public String RetornaNome(int tag) {
        try {
            Connection c = Conexao.obeterConexao();
            String sql = "SELECT adm FROM CYP.comunidade WHERE tag = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setInt(1, tag);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String adm = resultado.getString("adm");
                c.close();
                return adm;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro: " + ex.getMessage());
        }
        return null;
// Retorna null se não encontrar o e-mail no banco de dados.
    }
 public int TagUsuarioComunidade(Usuarios dados, Comunidade info) {
    try {
        Connection c = Conexao.obeterConexao();
        String sql = "SELECT tagUsuario.tag " +
                     "FROM CYP.comunidade " +
                     "JOIN CYP.usuario ON comunidade.TagUsuario = usuario.tag " +
                     "WHERE tag = ?";
        PreparedStatement consulta = c.prepareStatement(sql);
        // Defina os parâmetros ou a condição de junção conforme necessário
        // consulta.setString(1, algumValor);

        ResultSet resultado = consulta.executeQuery();

        if (resultado.next()) {
            int tag = resultado.getInt("tag");
            c.close();
            return tag;
        }
    } catch (SQLException ex) {
        Logger.getLogger(ServicosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("Erro: " + ex.getMessage());
    }
    return 0;
}
}
